<?php
defined('BASEPATH') OR exit('No direct script access allowed');
define('Success', "success");
define('Failure', "failure");

class Api extends CI_Controller {

	private $data;
	
	public function __construct(){
		parent::__construct();
		$this->data = file_get_contents('php://input');
		date_default_timezone_set('Asia/Calcutta'); 
	}
	
	public function signIn(){
		$data =  json_decode($this->data);
		$email = isset($data->email) ? $data->email : '';
		$password = isset($data->password) ? md5($data->password) : '';	
		$check_exist = $this->db->where('email',$email)->where('password',$password)->get('users')->num_rows();
		if($check_exist > 0){
		   $check_exist1 = $this->db->where('email',$email)->where('password',$password)->get('users')->row_array();		   
		   $output = array(
				'status' => Success,
				'message' => 'SignIn in  Successfully',
			    'data' => $check_exist1,
            );
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Unauthorized User!.",
				'data' => []
            );
		}
		echo json_encode($output); die;
	}
    
	public function getPlans(){		
		$plandata = $this->db->get('tbl_plans')->result_array();
		if(!empty($plandata)){
			$output = array(
				'status' => Success,
				'message' => 'Plans fetched successfully',
			    'data' => $plandata,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output); die;		
	}
	
	//
	public function getAuctions(){
		$data =  json_decode($this->data);
		$status = $data->status;
		$auction_id = $this->db->where('status',$status)->get('tbl_auction')->result_array();
		foreach($auction_id as $key => $value){
		   $bid_data =  $this->db->select_min('bid_amount')->select('member_id')->where('auction_id',$value['auction_id'])->get('tbl_bids')->row_array();
    	   $auction_id[$key]['bid_amount'] = $bid_data['bid_amount'];
    	   $auction_id[$key]['member_id'] = $bid_data['member_id'];
		}
	   
		if(!empty($auction_id)){
			$output = array(
				'status' => Success,
				'message' => 'Auction Fetched Successfully',
			    'data' => $auction_id,
            );
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
    public function getGroupInAPlan(){
		$data =  json_decode($this->data);
		$plan_id = $data->plan_id;
		$groupdata = $this->db->where('plan_id',$plan_id)->get('tbl_groups')->result_array();
		if(!empty($groupdata)){
			$output = array(
				'status' => Success,
				'message' => 'Groups Fetched Successfully',
			    'data' => $groupdata,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}


	public function getGroupDetails(){ // 21-02-22 Update 
		$data =  json_decode($this->data);		
		$group_id = isset($data->group_id) ? $data->group_id : '';
		$group_details = $this->db->where('group_id',$group_id)->get('tbl_groups')->row_array();
		$member_id = $this->db->where('plan_id',$group_details['plan_id'])->where('group_id',$group_id)->where('slot_status !=','cancelled')->order_by('order_id','asc')->get('tbl_orders')->result_array();		
		$group_plan_data = array();
	    $i=1;
		foreach($member_id as $keys=>$values){
		   if($values['slot_status'] != 'vacant'){
			$group_members = $this->db->where('member_id',$values['member_id'])->get('tbl_members')->row_array();
			$plan_data = $this->db->where('plan_id',$group_details['plan_id'])->get('tbl_plans')->row_array();
			$amount  = $this->convertAmountCurrency($plan_data['plan_amount']);
			$group_members['slot_number'] = isset($values['slot_number']) ? $values['slot_number'] : '';
			$group_members['slot_status'] = isset($values['slot_status']) ? $values['slot_status'] : '';
			$group_members['order_id'] = isset($values['order_id']) ? $values['order_id'] : '';
			$group_plan_data[] = array_merge($group_members,$plan_data);
		   }else{
		   $group_members = $this->db->where('member_id',69)->get('tbl_members')->row_array();
		   $group_members['slot_number'] = isset($values['slot_number']) ? $values['slot_number'] : '';
		   $group_members['slot_status'] = isset($values['slot_status']) ? $values['slot_status'] : '';
		   $group_members['order_id'] = isset($values['order_id']) ? $values['order_id'] : '';
		   $plan_data = $this->db->where('plan_id',$group_details['plan_id'])->get('tbl_plans')->row_array();
		   $group_plan_data[] = array_merge($group_members,$plan_data);
		
		   }
		   	$i++;
		}        
        
		if(!empty($group_plan_data)){
			$output = array(
				'status' => "Success",
				'message' => 'Group Members Fetched Successfully',
			    'data' => $group_plan_data,
			    'group_details' => $group_details,
            );
		}else{
			$output = array(
				'status' => "Failure",
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
	function convertAmountCurrency($number){
	   $length = strlen($number);
       $currency = '';

        if($length == 6 || $length == 7)
        {
            if($number <= 900000){
              $number1 = substr($number,0,-5);
              $value = "0".$number1;
              $ext = "L";
              $currency = $value.$ext;
            }else{
               $value = substr($number,0,-5);
               $ext = "L";
               $currency = $value.$ext;
            }
            
        }elseif($length == 8 || $length == 9){
           if($number >= 10000000){
              $number1 = substr($number,0,-7);
              $value = $number1;
              $ext = "Cr";
              $currency = $value.$ext;  
            } 
        }
        return $currency;
	}
	
public function getMembersInAuction(){ // 10jan2022		
		$data =  json_decode($this->data);
		$auction_id = isset($data->auction_id) ? $data->auction_id : '';
		$type = isset($data->type) ? $data->type : '';
		$getplangroup = $this->db->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
		$plan_id = isset($getplangroup['plan_id']) ? $getplangroup['plan_id'] : '';
		$group_id = isset($getplangroup['group_id']) ? $getplangroup['group_id'] : '';
    	if($type == "combined"){
    		$getorder = $this->db->select('member_id')->where('plan_id',$plan_id)->get('tbl_orders')->result_array(); // update to not get groups
    	}elseif($type == "individual" ){
    	    $getorder = $this->db->select('member_id')->where('plan_id',$plan_id)->where('group_id',$group_id)->get('tbl_orders')->result_array(); // update to not get groups
    	}
      if(!empty($getorder)){
		$getdata = array(); $getdata1 =array();
		foreach($getorder as $keys=>$values){
		$member_id = isset($values['member_id']) ? $values['member_id'] : '';
		$check_member_to_chit =  $this->db->where('member_id',$member_id)->get('tbl_chits')->num_rows();
			if(empty($check_member_to_chit)){				
				$getmemberdetail = $this->db->where('member_id',$member_id)->get('tbl_members')->row_array();
				$getdata[]= $getmemberdetail;
				$getdata1 = array_filter($getdata);
			}		
		}
		
		if(!empty($getdata1)){
			$output = array(
				'status' => Success,
				'message' => 'Memebers Details Fetched Successfully',
			    'data' => $getdata1,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
      }else{
        $output = array(
		'status' => Failure,
		'message' => "Invalid Data.",
		'data' => []
        );   
      }
		echo json_encode($output);die;
	}
	
	

	public function getAuctionDetails(){
		$data =  json_decode($this->data);
		$auction_id = $data->auction_id;
		$getauction = $this->db->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
		if(!empty($getauction)){
			$output = array(
				'status' => Success,
				'message' => 'Auction Details Fetched Successfully',
			    'data' => $getauction,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
	public function saveBidByAgent(){ 
		$data =  json_decode($this->data);
		$member_id = isset($data->member_id) ? $data->member_id : '' ;
		$auction_id = isset($data->auction_id) ? $data->auction_id : '';
		$for_go_amount = isset($data->for_go_amount) ? $data->for_go_amount : ''; // bid amount 
		$agent_id = isset($data->agent_id) ? $data->agent_id : '';
		$forman_fees = isset($data->forman_fees) ? $data->forman_fees : '';

		$daata = $this->db->select('forgo_amount')->where('auction_id',$auction_id)->get('tbl_bids')->result_array();
		$plan_id =    $this->db->select('plan_id,group_id')->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
		$group_id = isset($plan_id['group_id']) ? $plan_id['group_id'] : '';
		$plan_name =  $this->db->select('plan_name')->where('plan_id',$plan_id['plan_id'])->get('tbl_plans')->row_array();
	    $member_name =    $this->db->select('name')->where('member_id',$member_id)->get('tbl_members')->row_array();
	    $plan_amount_detail = $this->db->select('plan_amount,remaining_month')->where('plan_id',$plan_id['plan_id'])->get('tbl_plans')->row_array();
		$plan_amount = $plan_amount_detail['plan_amount'];
		$remaining_month = $plan_amount_detail['remaining_month'];
		$bid_amount = $plan_amount - $for_go_amount;
		$cost_of_chit_taken = ($bid_amount/$remaining_month)/($plan_amount - $bid_amount);	
	  if(!empty($daata)){
		foreach($daata as $keys=>$values){
			$datasa = isset($values['forgo_amount']) ? $values['forgo_amount'] : '';
			if ($datasa < $for_go_amount  && $for_go_amount > $forman_fees){
			  	$bid_is_bid = 'big';				
			}else{
				$bid_is_bid = 'small';
			}
		}
		if($bid_is_bid == 'small'){
			$output = array(
				'status' => Failure,
				'message' => "You must bid more than the previous bid",
				'data' => []
			);
		}else{
			if(!empty($agent_id)){
				$agent_ids = 1;
		   }else{
			   $agent_ids = 0;
		   }
		   
		   $data = array(
			 'auction_id' => isset($auction_id) ? $auction_id : '',
			 'plan_id' => isset($plan_id['plan_id']) ? $plan_id['plan_id'] : '',
			 'plan_name' => isset($plan_name['plan_name']) ? $plan_name['plan_name'] : '',
			 'group_id' => isset($group_id) ? $group_id : '',
			 'member_id' => isset($member_id) ? $member_id : '',
			 'is_bid_accepted' =>  'no',
			 'agent_id' => isset($agent_id) ? $agent_id : '',
			 'forgo_amount' =>  $for_go_amount,
			 'cost_of_chit_taken' => isset($cost_of_chit_taken) ? $cost_of_chit_taken : '',
			 'bid_amount' =>  isset($bid_amount) ? $bid_amount : '',
			 'member_name' => isset($member_name['name']) ? $member_name['name'] : '',
			 'is_added_by_agent' => isset($agent_ids) ? $agent_ids : '',
			 'added_date' => date('Y-m-d h:i:s')
		   );
		   
		   $this->db->insert('tbl_bids',$data);
		   $insert_id = $this->db->insert_id();
   
		   if(!empty($insert_id)){
			   $output = array(
				   'status' => Success,
				   'message' => 'Bid Save Successfully',
				   'data' => [],
			   );	
		   }else{
			   $output = array(
				   'status' => Failure,
				   'message' => "Invalid Data.",
				   'data' => []
			   );
		   }
		}
	  }else{
	      
	      if($forman_fees < $for_go_amount){
	
	        if(!empty($agent_id)){
				$agent_ids = 1;
		   }else{
			   $agent_ids = 0;
		   }
		   
		   $data = array(
			 'auction_id' => isset($auction_id) ? $auction_id : '',
			 'plan_id' => isset($plan_id['plan_id']) ? $plan_id['plan_id'] : '',
			 'plan_name' => isset($plan_name['plan_name']) ? $plan_name['plan_name'] : '',
			 'group_id' => isset($group_id) ? $group_id : '',
			 'member_id' => isset($member_id) ? $member_id : '',
			 'is_bid_accepted' =>  'no',
			 'agent_id' => isset($agent_id) ? $agent_id : '',
			 'forgo_amount' =>  $for_go_amount,
			 'cost_of_chit_taken' => isset($cost_of_chit_taken) ? $cost_of_chit_taken : '',
			 'bid_amount' =>  isset($bid_amount) ? $bid_amount : '',
			 'member_name' => isset($member_name['name']) ? $member_name['name'] : '',
			 'is_added_by_agent' => isset($agent_ids) ? $agent_ids : '',
			 'added_date' => date('Y-m-d h:i:s')
		   );
		   
		   $this->db->insert('tbl_bids',$data);
		   $insert_id = $this->db->insert_id();
   
		   if(!empty($insert_id)){
			   $output = array(
				   'status' => Success,
				   'message' => 'Bid Save Successfully',
				   'data' => [],
			   );	
		   }else{
			   $output = array(
				   'status' => Failure,
				   'message' => "Invalid Data.",
				   'data' => []
			   );
		   }
		
	      }else{
	        $output = array(
				'status' => Failure,
				'message' => 'Bid amount should be more than the minimum bid allowed ',
			    'data' => [],
            );   
	      }
	  }
		echo json_encode($output);die;		
	}
	
	public function bidsByAgent(){
	   	$data =  json_decode($this->data);
		$agent_id = $data->agent_id; 
		
		$bid_details = $this->db->where('agent_id',$agent_id)->get('tbl_bids')->result_array();
		if(!empty($bid_details)){
		    $output = array(
				'status' => Success,
				'message' => 'Bids Details Fetched Successfully',
			    'data' => $bid_details,
            );	
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            ); 
		}
	   echo json_encode($output);die;
	}

	public function memberAddedByAgent(){
	   	$data =  json_decode($this->data);
		$agent_id = $data->agent_id; 
		
		$members_details = $this->db->where('agent_id',$agent_id)->get('tbl_members')->result_array();
		if(!empty($members_details)){
		    $output = array(
				'status' => Success,
				'message' => 'Members Details Fetched Successfully',
			    'data' => $members_details,
            );	
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            ); 
		}
	   echo json_encode($output);die;
	}
	
	// clone set krna hai one day fequency m 
	//create function plan exipre 
	
	public function plansPurchasedByMember(){
	    $data =  json_decode($this->data);
		$member_id = $data->member_id; 
		$status = $data->status; 

		$members_details = $this->db->where('member_id',$member_id)->where('status',$status)->get('tbl_orders')->result_array();
		if(!empty($members_details)){
		    $output = array(
				'status' => Success,
				'message' => 'Plans Purchased By Member Fetched Successfully',
			    'data' => $members_details,
            );	
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            ); 
		}
	   echo json_encode($output);die;
	}
	
	public function getMembersDetails(){
	    $data =  json_decode($this->data);
		$member_id = isset($data->member_id) ? $data->member_id : ''; 
		$members_details = $this->db->where('member_id',$member_id)->get('tbl_members')->result_array();
		if(!empty($members_details)){
		    $output = array(
				'status' => Success,
				'message' => 'Members Details Fetched Successfully',
			    'data' => $members_details,
            );	
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            ); 
		}
	   echo json_encode($output);die;
	}
	
	public function getPlansDetails(){
	    $data =  json_decode($this->data);
		$plan_id = $data->plan_id; 

		$plans_details = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->result_array();
		if(!empty($plans_details)){
		    $output = array(
				'status' => Success,
				'message' => 'Plans Details Fetched Successfully',
			    'data' => $plans_details,
            );	
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            ); 
		}
	   echo json_encode($output);die;
	}
	
	
	public function addMember(){
	    $data =  json_decode($this->data);
		$member_name = isset($data->name) ? $data->name : ''; 
		$last_name = isset($data->last_name) ? $data->last_name : ''; 
		$father_name = isset($data->father_name) ? $data->father_name : ''; 
		$dob = isset($data->dob) ? $data->dob : ''; 
		$mobile = isset($data->mobile) ? $data->mobile : '';
	    $secondary_mobile = isset($data->secondary_mobile) ? $data->secondary_mobile : '';
	    $office_phone = isset($data->office_phone) ? $data->office_phone : '' ;
	    $email = isset($data->email) ? $data->email : '';
	    $permanent_address = isset($data->permanent_address) ?  $data->permanent_address  : '';
	    $current_potal_address = isset($data->current_potal_address)  ? $data->current_potal_address : '' ;
	    $reference = isset($data->reference)  ? $data->reference : '' ;
	    $marital_status = isset($data->marital_status) ? $data->marital_status : '';
	    $spouse_name = isset($data->spouse_name) ? $data->spouse_name : '' ;
	    $annivarsary_date = isset($data->annivarsary_date) ? $data->annivarsary_date : '';
	    $no_of_kids = isset($data->no_of_kids) ?  $data->no_of_kids : '';
	    $no_of_depends = isset($data->no_of_depend) ? $data->no_of_depend : '' ;
	    $no_of_nominee = isset($data->no_of_nominee) ? $data->no_of_nominee : '' ;
	    $nominee_name = isset($data->nominee_name) ? $data->nominee_name : '' ;
	    $nominee_relationship = isset($data->nominee_relationship) ? $data->nominee_relationship : '' ;
	    $nominee_d_o_b = isset($data->nominee_d_o_b) ? $data->nominee_d_o_b : '' ;
	    $percentage_of_nomination = isset($data->percentage_of_nomination) ? $data->percentage_of_nomination : '';
	    $nominee_gaurdian_name = isset($data->nominee_gaurdian_name) ? $data->nominee_gaurdian_name : '' ;
	    $pan_number = isset($data->pan_number) ? $data->pan_number : '' ;
	    $income_type = isset($data->income_type) ?  $data->income_type : '';
	    $company_name = isset($data->company_name) ?  $data->company_name : '' ;
	    $company_type = isset($data->company_type) ? $data->company_type : '' ;
	    $designation = isset($data->designation) ?  $data->designation : '';
	    $work_address = isset($data->work_address) ? $data->work_address : '';
	    $salary = isset($data->salary) ? $data->salary : '' ;
	    $other_income = isset($data->other_income)  ? $data->other_income : '';
	    $experience = isset($data->experience) ? $data->experience : '';
	   // $professional_service = $data->professional_service;
	    $office_address = isset($data->office_address) ? $data->office_address : '';
	    $employee_no =  isset($data->employee_no) ? $data->employee_no : '';
	    $gst_no = isset($data->gst_no) ?  $data->gst_no : '';
	    $annual_turnover =  isset($data->annual_turnover) ? $data->annual_turnover : '' ;
	    $income_source = isset($data->income_source) ? $data->income_source : '' ;
	    $monthly_income = isset($data->monthly_income) ? $data->monthly_income : '' ;
	    $car_category =  isset($data->car_category) ?  $data->car_category : '';
	    $two_wheeler_category = isset($data->two_wheeler_category) ? $data->two_wheeler_category : '';
	    $house_category = isset($data->house_category) ? $data->house_category : '' ;
	    $identity_category =  isset($data->identity_category) ?  $data->identity_category : '';
	    $address_category = isset($data->address_category) ?  $data->address_category : '';
	    $agent_id =  isset($data->agent_id) ? $data->agent_id : '';
	    $agent_comission  = isset($data->agent_comission) ? $data->agent_comission : '';
	    $adhaar_number = isset($data->adhaar_number) ? $data->adhaar_number : ''  ;
	    
	    if(!empty($agent_id)){
	        $is_added_by_agent = 1;
	    }else{
	        $is_added_by_agent = 0;
	    }
	    
	    
	    $data = array(
	     'name' =>   isset($member_name) ? $member_name : '',
	     'last_name' =>   isset($last_name) ? $last_name : '',
	     'father_name' => isset($father_name) ? $father_name : '',
	     'dob' => isset($dob) ? $dob : '',
	     'mobile' => isset($mobile) ? $mobile : '',
	     'secondary_mobile' => isset($secondary_mobile) ? $secondary_mobile : '',
	     'office_phone' => isset($office_phone) ? $office_phone : '',
	     'email' => isset($email) ? $email : '',
	     'permanent_address' => isset($permanent_address) ? $permanent_address : '',
	     'current_potal_address' => isset($current_potal_address) ? $current_potal_address : '',
	     'reference' => isset($reference) ? $reference : '',
	     'marital_status' => isset($marital_status) ? $marital_status : '',
	     'spouse_name' => isset($spouse_name) ? $spouse_name : '',
	     'annivarsary_date' => isset($annivarsary_date) ? $annivarsary_date : '',
	     'no_of_kids' =>    isset($no_of_kids) ? $no_of_kids : '',
	     'no_of_depends' => isset($no_of_depends) ? $no_of_depends : '',
	     'no_of_nominee' => isset($no_of_nominee) ? $no_of_nominee : '',
	     'nominee_name' => isset($nominee_name) ? $nominee_name : '',
	     'nominee_relationship' => isset($nominee_relationship) ? $nominee_relationship : '',
	     'nominee_d_o_b' =>  isset($nominee_d_o_b) ? $nominee_d_o_b : '',
	     'percentage_of_nomination' => isset($percentage_of_nomination) ? $percentage_of_nomination : '',
	     'nominee_gaurdian_name' => isset($nominee_gaurdian_name) ? $nominee_gaurdian_name : '',
	     'pan_number' => isset($pan_number) ? $pan_number : '',
	     'income_type' => isset($income_type) ? $income_type : '',
	     'company_name' => isset($company_name) ? $company_name : '',
	     'company_type' => isset($company_type) ? $company_type : '',
	     'designation' => isset($designation) ? $designation : '',
	     'work_address' => isset($work_address) ? $work_address : '',
	     'salary' =>  isset($salary) ? $salary : '',
	     'other_income' => isset($other_income) ? $other_income : '',
	     'experience'  => isset($experience) ? $experience : '',
	//     'professional_service' => isset($professional_service) ? $professional_service : '',
	     'office_address' => isset($office_address) ? $office_address : '',
	     'employee_no' => isset($employee_no) ? $employee_no : '',
	     'gst_no' => isset($gst_no) ? $gst_no : '',
	     'annual_turnover'  => isset($annual_turnover) ? $annual_turnover : '',
	     'income_source'  => isset($income_source) ? $income_source : '',
	     'monthly_income' => isset($monthly_income) ? $monthly_income : '',
	     'car_category' => isset($car_category) ? $car_category : '',
	     'two_wheeler_category' => isset($two_wheeler_category) ? $two_wheeler_category : '',
	     'house_category'  => isset($house_category) ? $house_category : '',
	     'identity_category' => isset($identity_category) ? $identity_category : '',
	     'address_category'  => isset($address_category) ? $address_category : '',
	     'is_added_by_agent' => isset($is_added_by_agent) ? $is_added_by_agent : '',
	     'agent_id' => isset($agent_id) ? $agent_id : '',
	     'agent_comission' => isset($agent_comission) ? $agent_comission : '',
	     'adhaar_number' => isset($adhaar_number) ? $adhaar_number : '',
	     'added_date' => date('Y-m-d h:i:s')
	    );
	    
	    $this->db->insert('tbl_members',$data);
	    $insert_id = $this->db->insert_id();
	   
		$members_details = $this->db->where('member_id',$insert_id)->get('tbl_members')->row_array();
		if(!empty($members_details)){
		    $output = array(
				'status' => Success,
				'message' => 'Members Details Fetched Successfully',
			    'data' => $members_details,
            );	
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            ); 
		}
	   echo json_encode($output);die;
	   
	}
	
	public function getAgentDetails(){
	    $data =  json_decode($this->data);
		$agent_id = $data->agent_id; 
	   if($agent_id != ''){
	    $getAgentDetails = $this->db->where('agent_id',$agent_id)->get('tbl_agent')->row_array();
	    if(!empty($getAgentDetails)){
	         $output = array(
				'status' => Success,
				'message' => 'Agent Details Fetched Successfully',
			    'data' => $getAgentDetails,
            );	
	    }else{
	        $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );  
	    }
	   }else{
	       $output = array(
				'status' => Failure,
				'message' => "Invalid Agent Id.",
				'data' => []
            );   
	   }
	    echo json_encode($output);die;
	}
	
	
	public function updateMembers(){
	    $data =  json_decode($this->data);
	    $member_id = $data->member_id; 
		$member_name = $data->name; 
		$email = $data->email; 
		$mobile = $data->mobile;
		$address = $data->address;
	   if($member_id !=''){
		$data = array(
		  'name' => isset($member_name) ? $member_name : '',
		  'email' =>  isset($email) ? $email : '',
		  'mobile' => isset($mobile) ? $mobile : '',
		  'permanent_address' => isset($address) ? $address : '',
		  'update_date' => date('Y-m-d h:i:s')
		);
		
		$this->db->where('member_id',$member_id)->update('tbl_members',$data);
		$output = array(
			'status' => Success,
			'message' => 'Update Members Successfully',
            );
	   }else{
	      $output = array(
				'status' => Failure,
				'message' => "Invalid Member Id.",
				'data' => []
            );   
	   }
	   echo json_encode($output);die;
	}
	
	public function addAgent(){
	    $data =  json_decode($this->data);
	    $first_name = $data->first_name; 
		$last_name = $data->last_name; 
		$email = $data->email; 
		$phone = $data->phone;
		$gst_no = $data->gst_no;
		$company = $data->company; 
		$payment_terms = $data->payment_terms; 
		$address = $data->address; 
		$city = $data->city;
		$state = $data->state;
		$country = $data->country; 
		$data = array(
            'first_name' => isset($first_name) ? $first_name : '',
            'last_name' => isset($last_name) ? $last_name : '',
            'email' => isset($email) ? $email : '',
            'phone' => isset($phone) ? $phone : '',
            'gst_no' => isset($gst_no) ? $gst_no : '',
            'company' => isset($company) ? $company : '',
            'payment_terms' => isset($payment_terms) ? $payment_terms : '',
            'address' => isset($address) ? $address : '',
            'city' => isset($city) ? $city : '',
            'state' => isset($state) ? $state : '',
            'country' => isset($country) ? $country : '',
            'added_date' => date('Y-m-d h:i:s')
        );
        
		$this->db->insert('tbl_agent',$data);
		$insert_id = $this->db->insert_id(); 
	   if(!empty($insert_id)){
		$output = array(
			'status' => Success,
			'message' => 'Agent  Successfully',
			'data' => $insert_id
            );
	   }else{
	      $output = array(
				'status' => Failure,
				'message' => "Invalid Agent Id.",
				'data' => []
            );   
	   }
	   echo json_encode($output);die;
	}
	
	public function getAllAgentDetails(){
	    $getAgentDetails = $this->db->get('tbl_agent')->result_array();
	    if(!empty($getAgentDetails)){
	         $output = array(
				'status' => Success,
				'message' => 'Agent Details Fetched Successfully',
			    'data' => $getAgentDetails,
            );	
	    }else{
	        $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );  
	    }
	    echo json_encode($output);die;
	}
	
	public function getAllAgent(){
	    $getAgentDetails = $this->db->where('agent_id',$agent_id)->get('tbl_agent')->row_array();
	    if(!empty($getAgentDetails)){
	         $output = array(
				'status' => Success,
				'message' => 'Agent Details Fetched Successfully',
			    'data' => $getAgentDetails,
            );	
	    }else{
	        $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );  
	    }
	    echo json_encode($output);die;
	}
	
	public function getAllMemberDetails(){
	    $getMemberDetails = $this->db->get('tbl_members')->result_array();
	    if(!empty($getMemberDetails)){
	         $output = array(
				'status' => Success,
				'message' => 'Members Details Fetched Successfully',
			    'data' => $getMemberDetails,
            );	
	    }else{
	        $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );  
	    }
	    echo json_encode($output);die;
	}
	
	public function addPlan(){  //21-02-22 Update
	    $data =  json_decode($this->data);
	    $plan_name = isset($data->plan_name) ? $data->plan_name : '' ; 
		$admission_fee = isset($data->admission_fee) ? $data->admission_fee : '' ; 
		$plan_amount = isset($data->plan_amount) ? $data->plan_amount : ''; 
		$tenure = isset($data->tenure) ? $data->tenure : '' ;
		$start_month = isset($data->start_month) ? $data->start_month : '';
		$agent_commission = isset($data->agent_commission) ? $data->agent_commission : ''; 
		$emi = isset($data->emi) ? $data->emi : ''; 
		$foreman_fees = isset($data->foreman_fees) ? $data->foreman_fees : '';
		$min_prize_amount = isset($data->min_prize_amount) ? $data->min_prize_amount : '';
		$total_months = isset($data->total_months) ? $data->total_months : '';
		$groups_counts = isset($data->groups_counts) ? $data->groups_counts : ''; 
		$end_date_for_subscription = isset($data->end_date_for_subscription) ?  $data->end_date_for_subscription : '';
		$max_bid = isset($data->max_bid) ?  $data->max_bid : '';
		$min_prize_amount = ($plan_amount) -($plan_amount * $max_bid/100);
		$min_bid_amount = $plan_amount * $foreman_fees/100;
	    $total_subscription = $tenure * $groups_counts;
        $emi = $plan_amount / $tenure;
		 $data = array(
             'plan_name' =>   isset($plan_name) ?  $plan_name : '',
             'admission_fee' =>   isset($admission_fee) ?  $admission_fee : '',
             'plan_amount' =>   isset($plan_amount) ?  	$plan_amount : '',
             'tenure' =>   isset($tenure) ?  $tenure : '',
             'start_month' =>   isset($start_month) ?  $start_month : '',
             'agent_commission' =>   isset($agent_commission) ?  $agent_commission : '',
             'emi' =>   isset($emi) ?  $emi : '',
			 'foreman_fees' =>   isset($foreman_fees) ?  $foreman_fees : '',
			 'min_prize_amount' =>   isset($min_prize_amount) ?  $min_prize_amount : '',
             'total_subscription' =>   isset($total_subscription) ?  $total_subscription : '',  
             'max_bid' =>   isset($max_bid) ?  $max_bid : '',  
             'remaining_month' =>   isset($total_months) ?  $total_months : '',  
             'months_completed' => '0',  
             'total_months' =>   isset($total_months) ?  $total_months : '',  
             'groups_counts' =>   isset($groups_counts) ?  $groups_counts  : '',  
             'end_date_for_subscription' =>   isset($end_date_for_subscription) ?  $end_date_for_subscription : '', 
             'min_bid_amount' =>   isset($min_bid_amount) ?  $min_bid_amount : '', 
             'status' => 'active',
             'added_date' => date('y-m-d h:i:s')
            );
			$this->db->insert('tbl_plans',$data);
	    	$insert_id = $this->db->insert_id();
		    $ParticiDetails = isset($groups_counts) ?  $groups_counts  : '';		
			$char_arr = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
			for($kk=0; $kk<$ParticiDetails; $kk++){
				$data2 = array(
				'plan_id'=> isset($insert_id) ?  $insert_id : '',				
				'total_members' => isset($tenure) ?  $tenure : '',	
				'group_name' => isset($char_arr[$kk]) ?  $char_arr[$kk] : '',
				'added_date' => date('Y-m-d h:i:s')
			);			
			$this->db->insert('tbl_groups',$data2);			
		   }
		 $group_data = $this->db->select('group_id,total_members')->where('plan_id',$insert_id)->get('tbl_groups')->result_array();
		 if(!empty($group_data)){
	    foreach($group_data as $key => $value){
	      $total_member = isset($value['total_members']) ? $value['total_members'] : '';
	      $group_id = isset($value['group_id']) ? $value['group_id'] : '';
	      $group_name = isset($value['group_name']) ? $value['group_name'] : '';
          $group_data1 = $this->db->where('plan_id',$insert_id)->where('group_id',$group_id)->get('tbl_orders')->num_rows();
	       if($group_data1 >= $total_member){
	              $output = array(
            		'status' => Success,
            		'message' => "All Order Slot Booked",
            		'data' => []
                  ); 
                continue;
	       }else{
	          $emi = round($emi, 0);
	          for($i=1; $i<=$total_member; $i++){
            	$amount  = $this->convertAmountCurrency($plan_amount);
		        $slot_number = $plan_name.date('m',strtotime($start_month)).date('y',strtotime($start_month)).$amount.$i;
	            $data = array(
            	    'member_id' => isset($member_id) ? $member_id : '',
            	    'plan_id'   => isset($insert_id) ? $insert_id : '',
            	    'group_id'  => isset($group_id) ? $group_id : '',
            	    'member_name' => isset($member_name) ? $member_name : '',
            	    'plan_amount' => isset($plan_amount) ? $plan_amount : '',
            	    'start_month' => isset($start_month) ? $start_month : '',
            	    'emi' => isset($emi) ? $emi : '',
            	    'tenure' => isset($tenure) ? $tenure : '',
            	    'months_completed' => 0,
            	    'agent_commission' => isset($agent_commission)  ? $agent_commission : '',
            	    'end_month' => isset($end_date_for_subscription) ? $end_date_for_subscription : '',
            	    'total_months' => isset($total_months) ? $total_months : '',
            	    'groups_count'  => isset($groups_counts) ? $groups_counts : '',
            	    'admission_fees'    => isset($admission_fee) ? $admission_fee : '',
            	    'agent_id'  => isset($agent_id) ? $agent_id : '',
            	    'is_added_by_agent' => isset($is_added_by_agent) ? $is_added_by_agent : '0',
            	    'transaction_id' => isset($transaction_id) ? $transaction_id : '',
            	    'payment_mode' => isset($payment_mode) ? $payment_mode : '',
            	    'slot_number' => isset($slot_number) ? $slot_number : '',
            	    'added_date' => date('Y-m-d h:i:s')
            	  );
            	  
        	      $this->db->insert('tbl_orders',$data);
                  $insert_id1 = $this->db->insert_id();
            	   if(!empty($insert_id1)){
            	        $output = array(
            				'status' => Success,
            				'message' => 'Save Order Successfully',
            			    'data' => [],
                        );	 
            	   }else{
            	      $output = array(
            				'status' => Failure,
            				'message' => "Invalid Data.",
            				'data' => []
                        ); 
            	    }
	             }
	       }
	  }
	 }else{
	    $output = array(
    		'status' => Failure,
    		'message' => "Data not found.",
    		'data' => []
            );  
	 }
	  echo json_encode($output); die;
	}


	public function planUpdate(){
		$data =  json_decode($this->data);
		$plan_id = $data->plan_id;
		$data= $this->db->Where('plan_id',$plan_id)->get('tbl_plans')->row_array();
		if(!empty($data)){
			$output = array(
				'status' => Success,
				'message' => 'Plan Details Fetched Successfully',
			    'data' => $data,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
	public function planUpdateDetails(){
	    $data =  json_decode($this->data);
	    $plan_id = $data->plan_id; 
	    $plan_name = $data->plan_name; 
		$admission_fee = $data->admission_fee; 
		$plan_amount = $data->plan_amount; 
		$tenure = $data->tenure;
		$start_month = $data->start_month;
		$agent_commission = $data->agent_commission; 
		$emi = $data->emi; 
	    $foreman_fees = $data->foreman_fees;
		$min_prize_amount = $data->min_prize_amount;
		$total_subscription = $data->total_subscription; 
		$months_completed = $data->months_completed;
		$total_months = $data->total_months;
		$groups_counts = $data->groups_counts; 
		$end_date_for_subscription = $data->end_date_for_subscription; 
     
		 $data = array(
             'plan_name' =>   isset($plan_name) ?  $plan_name : '',
             'admission_fee' =>   isset($admission_fee) ?  $admission_fee : '',
             'plan_amount' =>   isset($plan_amount) ?  	$plan_amount : '',
             'tenure' =>   isset($tenure) ?  $tenure : '',
             'start_month' =>   isset($start_month) ?  $start_month : '',
             'agent_commission' =>   isset($agent_commission) ?  $agent_commission : '',
             'emi' =>   isset($emi) ?  $emi : '',
             'foreman_fees' =>   isset($foreman_fees) ?  $foreman_fees : '',
			 'min_prize_amount' =>   isset($min_prize_amount) ?  $min_prize_amount : '',
             'total_subscription' =>   isset($total_subscription) ?  $total_subscription : '',  
             'months_completed' =>   isset($months_completed) ?  $months_completed : '',  
             'total_months' =>   isset($total_months) ?  $total_months : '',  
             'groups_counts' =>   isset($groups_counts) ?  $groups_counts  : '',  
             'end_date_for_subscription' =>   isset($end_date_for_subscription) ?  $end_date_for_subscription : '', 
             'added_date' => date('y-m-d h:i:s')
            );
         if(!empty($plan_id)){   
	    	$this->db->where('plan_id',$plan_id)->update('tbl_plans',$data);
    		$output = array(
    			'status' => Success,
    			'message' => 'Plans Update Successfully',
    			'data' => []
            );
	   }else{
	      $output = array(
				'status' => Failure,
				'message' => "Invalid Agent Id.",
				'data' => []
            );   
	   }
	   echo json_encode($output);die;
	}
	
	public function getEmiInPlan(){	  	
		$data =  json_decode($this->data);
		$member_id = isset($data->member_id) ? $data->member_id : ''; 
		$plan_id_detail = $this->db->where('member_id',$member_id)->get('tbl_emi')->row_array();
		$plan_id = isset($plan_id_detail['plan_id']) ? $plan_id_detail['plan_id'] : '';
		$plan_detail = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
		$months_completed = isset($plan_detail['months_completed']) ? $plan_detail['months_completed'] : '';		
		$new_arr = array();
		for ($i=1; $i<=$months_completed; $i++){
			$getchitemi = $this->db->where('emi_status','due')->where('emi_no',$i)->where('member_id',$member_id)->get('tbl_emi')->result_array();			
			$new_arr[] = $getchitemi;
		}
		$newarray = array();
		foreach($new_arr as $key=>$value){
			foreach( $value as $keys=>$values ){
			  $newarray[] = $values['emi_id'];
			}			
		}
		$newchitarray = array();
		foreach( $newarray as $key=>$values){
			$getchit = $this->db->where('emi_id',$values)->get('tbl_emi')->row_array();
			$newchitarray[] = $getchit;
		}
		if(!empty($newchitarray) && !empty($newchitarray)){			 
	       $output = array(
			'status' => Success,
			'message' => 'Emi Fetched Successfully',
			'data' => $newchitarray
            );
	   }else{
	       $output = array(
				'status' => Failure,
				'message' => "Invalid data.",
				'data' => []
            );    
	   }
	   echo json_encode($output); die;
	}
	
	public function payEmi(){
	    $data =  json_decode($this->data);
	    $emi_id = $data->emi_id; 
		$emi_amount = $data->emi_amount; 
		$status = $data->status; 

	   if(!empty($emi_id) &&  !empty($emi_amount) && !empty($status)){		   
	      if($status == 'chit_emi'){
			$data = $this->db->where('chit_emi_id',$emi_id)->get('chit_emi')->row_array();
			if(!empty($data)){
				if($data['emi_status'] == 'due'){
					if($data['chit_emi'] == $emi_amount){
						$update_status = array(
						'emi_status' =>'paid'
					);
					$update = $this->db->where('chit_emi_id',$emi_id)->update('chit_emi',$update_status);
					}else{
						$output = array(
							'status'=>'failed',
							'message'=>' Amount doesnot matched.'
						);
					}
				}
				if($data['emi_status'] == 'paid'){
					$output = array(
						'status' => 'failed',
						'message' => ' Emi paid already'
							);
				}
			  }  
			}			
		  
		  	if($status == 'plan_emi'){
			$data = $this->db->where('emi_id',$emi_id)->get('tbl_emi')->row_array();
			if(!empty($data)){
				if($data['emi_status'] == 'due'){
					if($data['plan_emi'] == $emi_amount){
						$update_status = array(
						'emi_status' =>'paid'
					);
					$update = $this->db->where('emi_id',$emi_id)->update('tbl_emi',$update_status);
					}else{
						$output = array(
							'status'=>'failed',
							'message'=>' Amount doesnot matched.'
						);
					}
				}
				if($data['emi_status'] == 'paid'){
					$output = array(
						'status' => 'failed',
						'message' => ' Emi paid already'
							);
				}
			}						
			}  	
			if(!empty($update)){
				$output = array(
					'status'=>'success',
					'message'=>'payed emi successfully',
					'data'=>[]
				);				
			}	
			if(empty($data)){
				$output = array(
					'status'=>'failed',
					'message'=>'No record found for this emi id.',
					'data'=>[]
				);				
			}	 
		}
		else{
			$output = array(
				'status'=>'failed',
				'message'=>'in valid data',
				'data'=>[]
			);
		}
	   echo json_encode($output); die;
	}
	
	
	public function getPlansAvailableForAuction(){		
		$plandata = $this->db->get('tbl_plans')->result_array();
		if(!empty($plandata)){
			$output = array(
				'status' => Success,
				'message' => 'Plans fetched successfully',
			    'data' => $plandata,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output); die;		
	}
	
	//Pending 
	function getPercentageCalculation(){
	    
	}
	
     public function startAuction(){	// 10jan2021
	    $data =  json_decode($this->data);
	    $plan_id = isset($data->plan_id) ? $data->plan_id : '';  // planid, groupid, date, start time ,end time
	    $group_id = isset($data->group_id) ? $data->group_id : ''; 
	    $start_date = isset($data->start_date) ? $data->start_date : ''; 
		$start_time = isset($data->startTime) ? $data->startTime : ''; 
		$end_time = isset($data->end_time)  ? $data->end_time : ''; 
		
		$string = preg_replace('/\s+/', '', $start_time);		
		$time=date_create($string);
		$start_time = date_format($time,"H:i:s");
		
		$string = preg_replace('/\s+/', '', $end_time);		
		$time=date_create($string);
		$end_time = date_format($time,"H:i:s");

        if(!empty($plan_id)){
        //  $getPercentage = $this->getPercentageCalculation($min_prize_amount,$plan_amount);
			$getplan = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
			$foreman_fees = $getplan['foreman_fees'];
			$min_prize_amount = $getplan['min_prize_amount'];
			$plan_amount = $getplan['plan_amount'];
			$months_completed = $getplan['months_completed'];

           $data = array(
             'plan_id' => $plan_id,
			 'group_id' => $group_id,
             'start_date' => $start_date,
             'end_date' => $start_date,
			 'start_time' => $start_time,
			 'end_time' => $end_time,
             'status' => "2",
             'auction_no' => $months_completed+1,
			 'foreman_fees' => $foreman_fees,
			 'min_prize_amount' => $min_prize_amount,
			 'plan_amount' => $plan_amount,
             'added_date' => date('Y-m-d h:i:s')
           );
          $this->db->insert('tbl_auction',$data);
          $insert_id = $this->db->insert_id();

		    $getstatus = $this->db->select('status')->where('plan_id',$plan_id)->get('tbl_auction')->row_array();
			$status = $getstatus['status'];
			$data2 = array(
				'status' => $status,
			);
			$this->db->where('plan_id',$plan_id)->update('tbl_groups',$data2);

          if(!empty($insert_id)){
			$output = array(
				'status' => Success,
				'message' => 'Auction Started Successfully',
			    'data' => [],
            );	
    		}else{
    			$output = array(
    				'status' => Failure,
    				'message' => "Invalid Data.",
    				'data' => []
                );
    		}
        }else{
                        // echo 'abc';die;

			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output); die;		
	}
	
	public function agentUpdate(){
		$data =  json_decode($this->data);
		$agent_id = isset($data->agent_id) ? $data->agent_id : '' ;
		$data= $this->db->Where('agent_id',$agent_id)->get('tbl_agent')->row_array();
		if(!empty($data)){
			$output = array(
				'status' => Success,
				'message' => 'Agent Fetched Successfully',
			    'data' => $data,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
	public function agentUpdateDetails(){
		$data =  json_decode($this->data);
		$firstname = isset($data->fname) ? $data->fname : '';
		$lastname = isset($data->lname) ? $data->lname : '';
		$email = isset($data->email) ? $data->email : '';
		$phone = isset($data->phone) ? $data->phone : '';
		$gst_no = isset($data->gst_no) ? $data->gst_no : '';
		$company = isset($data->company) ? $data->company : '';
		$payment_terms = isset($data->payment_terms) ? $data->payment_terms : '';
		$address = isset($data->address) ? $data->address : '';
		$city = isset($data->city) ? $data->city : '';
		$state = isset($data->state) ? $data->state : '';
		$country = isset($data->country) ? $data->country : '';
		$agent_id = isset($data->agent_id) ? $data->agent_id : '' ;
		$data = array(
                'first_name' => isset($firstname) ? $firstname : '',
                'last_name' => isset($lastname) ? $lastname : '',
                'email' => isset($email) ? $email : '',
                'phone' => isset($phone) ? $phone : '',
                'gst_no' => isset($gst_no) ? $gst_no : '',
                'company' => isset($company) ? $company : '',
                'payment_terms' => isset($payment_terms) ? $payment_terms : '',
                'address' => isset($address) ? $address : '',
                'city' => isset($city) ? $city : '',
                'state' => isset($state) ? $state : '',
                'country' => isset($country) ? $country : '',
                'update_date' => date('Y-m-d h:i:s')
            );
        if(!empty($agent_id)){
		    $this->db->Where('agent_id',$agent_id)->update('tbl_agent',$data);
			$output = array(
				'status' => Success,
				'message' => 'Agent Update Successfully',
			    'data' => [],
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
	public function agentDelete(){
		$data =  json_decode($this->data);	
		$agent_id = isset($data->agent_id) ? $data->agent_id : '' ; 
		if(!empty($agent_id)){
	    	$this->db->where('agent_id',$agent_id)->delete('tbl_agent');
			$output = array(
				'status' => Success,
				'message' => 'Delete agent successfully',
				'data' => []
			);
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Agent Id.",
				'data' => []
			);   
		}
		echo json_encode($output);die;
	}
	
	public function subscriberupdate(){
		$data =  json_decode($this->data);
		$member_id = isset($data->member_id) ? $data->member_id : '' ;
		$data= $this->db->Where('member_id',$member_id)->get('tbl_members')->row_array();
		if(!empty($data)){
			$output = array(
				'status' => Success,
				'message' => 'Member  Fetched Successfully',
			    'data' => $data,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
    public function subscriberUpdateDetails(){
	    $data =  json_decode($this->data);
	    $member_id = isset($data->member_id) ? $data->member_id : ''; 
		$member_name = isset($data->name) ? $data->name : ''; 
		$father_name = isset($data->father_name) ? $data->father_name : ''; 
		$dob = isset($data->dob) ? $data->dob : ''; 
		$mobile = isset($data->mobile) ? $data->mobile : '';
	    $secondary_mobile = isset($data->secondary_mobile) ? $data->secondary_mobile : '';
	    $office_phone = isset($data->office_phone) ? $data->office_phone : '' ;
	    $email = isset($data->email) ? $data->email : '';
	    $permanent_address = isset($data->address) ?  $data->address  : '';
	    $current_potal_address = isset($data->potal_address)  ? $data->potal_address : '' ;
	    $marital_status = isset($data->marital_status) ? $data->marital_status : '';
	    $spouse_name = isset($data->spouse_name) ? $data->spouse_name : '' ;
	    $annivarsary_date = isset($data->annivarsary_date) ? $data->annivarsary_date : '';
	    $no_of_kids = isset($data->kids) ?  $data->kids : '';
	    $no_of_depends = isset($data->dependents) ? $data->dependents : '' ;
	    $no_of_nominee = isset($data->nominee) ? $data->nominee : '' ;
	    $nominee_name = isset($data->nominee_name) ? $data->nominee_name : '' ;
	    $nominee_relationship = isset($data->nominee_relationship) ? $data->nominee_relationship : '' ;
	    $nominee_d_o_b = isset($data->nominee_dob) ? $data->nominee_dob : '' ;
	    $percentage_of_nomination = isset($data->nominee_percentage) ? $data->percentage_of_nomination : '';
	    $nominee_gaurdian_name = isset($data->guardian_name) ? $data->guardian_name : '' ;
	    $pan_number = isset($data->Pan) ? $data->Pan : '' ;
	    $income_type = isset($data->income_type) ?  $data->income_type : '';
	    $company_name = isset($data->company_name) ?  $data->company_name : '' ;
	    $company_type = isset($data->company_type) ? $data->company_type : '' ;
	    $designation = isset($data->designation) ?  $data->designation : '';
	    $work_address = isset($data->work_address) ? $data->work_address : '';
	    $salary = isset($data->salary) ? $data->salary : '' ;
	    $other_income = isset($data->other_income)  ? $data->other_income : '';
	    $experience = isset($data->experience) ? $data->experience : '';
	   // $professional_service = $data->professional_service;
	    $office_address = isset($data->office_address) ? $data->office_address : '';
	    $employee_no =  isset($data->employee_no) ? $data->employee_no : '';
	    $gst_no = isset($data->gst_no) ?  $data->gst_no : '';
	    $annual_turnover =  isset($data->annual_turnover) ? $data->annual_turnover : '' ;
	    $income_source = isset($data->income_source) ? $data->income_source : '' ;
	    $monthly_income = isset($data->monthly_income) ? $data->monthly_income : '' ;
	    $car_category =  isset($data->car_category) ?  $data->car_category : '';
	    $two_wheeler_category = isset($data->two_wheeler_category) ? $data->two_wheeler_category : '';
	    $house_category = isset($data->house_category) ? $data->house_category : '' ;
	    $identity_category =  isset($data->identity_category) ?  $data->identity_category : '';
	    $address_category = isset($data->address_category) ?  $data->address_category : '';
	    $agent_id =  isset($data->agent_id) ? $data->agent_id : '';
	    $agent_comission  = isset($data->agent_comission) ? $data->agent_comission : '';
	    $adhaar_number = isset($data->Aadhar) ? $data->Aadhar : ''  ;
	    
	    if(!empty($agent_id)){
	        $is_added_by_agent = 1;
	    }else{
	        $is_added_by_agent = 0;
	    }
	    
	    $data = array(
	     'name' =>   isset($member_name) ? $member_name : '',
	     'father_name' => isset($father_name) ? $father_name : '',
	     'dob' => isset($dob) ? $dob : '',
	     'mobile' => isset($mobile) ? $mobile : '',
	     'secondary_mobile' => isset($secondary_mobile) ? $secondary_mobile : '',
	     'office_phone' => isset($office_phone) ? $office_phone : '',
	     'email' => isset($email) ? $email : '',
	     'permanent_address' => isset($permanent_address) ? $permanent_address : '',
	     'current_potal_address' => isset($current_potal_address) ? $current_potal_address : '',
	     'marital_status' => isset($marital_status) ? $marital_status : '',
	     'spouse_name' => isset($spouse_name) ? $spouse_name : '',
	     'annivarsary_date' => isset($annivarsary_date) ? $annivarsary_date : '',
	     'no_of_kids' =>    isset($no_of_kids) ? $no_of_kids : '',
	     'no_of_depends' => isset($no_of_depends) ? $no_of_depends : '',
	     'no_of_nominee' => isset($no_of_nominee) ? $no_of_nominee : '',
	     'nominee_name' => isset($nominee_name) ? $nominee_name : '',
	     'nominee_relationship' => isset($nominee_relationship) ? $nominee_relationship : '',
	     'nominee_d_o_b' =>  isset($nominee_d_o_b) ? $nominee_d_o_b : '',
	     'percentage_of_nomination' => isset($percentage_of_nomination) ? $percentage_of_nomination : '',
	     'nominee_gaurdian_name' => isset($nominee_gaurdian_name) ? $nominee_gaurdian_name : '',
	     'pan_number' => isset($pan_number) ? $pan_number : '',
	     'income_type' => isset($income_type) ? $income_type : '',
	     'company_name' => isset($company_name) ? $company_name : '',
	     'company_type' => isset($company_type) ? $company_type : '',
	     'designation' => isset($designation) ? $designation : '',
	     'work_address' => isset($work_address) ? $work_address : '',
	     'salary' =>  isset($salary) ? $salary : '',
	     'other_income' => isset($other_income) ? $other_income : '',
	     'experience'  => isset($experience) ? $experience : '',
	//     'professional_service' => isset($professional_service) ? $professional_service : '',
	     'office_address' => isset($office_address) ? $office_address : '',
	     'employee_no' => isset($employee_no) ? $employee_no : '',
	     'gst_no' => isset($gst_no) ? $gst_no : '',
	     'annual_turnover'  => isset($annual_turnover) ? $annual_turnover : '',
	     'income_source'  => isset($income_source) ? $income_source : '',
	     'monthly_income' => isset($monthly_income) ? $monthly_income : '',
	     'car_category' => isset($car_category) ? $car_category : '',
	     'two_wheeler_category' => isset($two_wheeler_category) ? $two_wheeler_category : '',
	     'house_category'  => isset($house_category) ? $house_category : '',
	     'identity_category' => isset($identity_category) ? $identity_category : '',
	     'address_category'  => isset($address_category) ? $address_category : '',
	     'is_added_by_agent' => isset($is_added_by_agent) ? $is_added_by_agent : '',
	     'agent_id' => isset($agent_id) ? $agent_id : '',
	     'agent_comission' => isset($agent_comission) ? $agent_comission : '',
	     'adhaar_number' => isset($adhaar_number) ? $adhaar_number : '',
	     'added_date' => date('Y-m-d h:i:s')
	    );
	  if(!empty($member_id)){
	        $this->db->where('member_id',$member_id)->update('tbl_members',$data);
		    $output = array(
				'status' => Success,
				'message' => 'Members Update Successfully',
			    'data' => [],
            );	
		}else{
		    $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            ); 
		}
	   echo json_encode($output);die;
	}
	
	public function checkIfPlanAlreadyPurchased($member_id = '',$plan_id = ''){
	   $check_member = $this->db->where('plan_id',$plan_id)->where('member_id',$member_id)->get('tbl_orders')->num_rows();
	   if($check_member <= 0){
	       return true;
	   }else{
	       return false;
	   }
	}
	
    public function BuyPlanByAgent(){
	  $data =  json_decode($this->data);
	  $member_id = isset($data->member_id) ? $data->member_id : '' ;
	  $plan_id = isset($data->plan_id) ? $data->plan_id : '';
	  $member_name = isset($data->member_name) ? $data->member_name : '';
	  $agent_id = isset($data->agent_id) ? $data->agent_id : '' ;
	  $transaction_id = isset($data->transaction_id) ? $data->transaction_id : '';
	  $payment_mode = isset($data->payment_mode) ? $data->payment_mode : '';
	  $getplan = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
	  $admission_fees =  isset($getplan['admission_fee']) ? $getplan['admission_fee'] : '';
	  $start_month =  isset($getplan['start_month']) ? $getplan['start_month'] : '';
	  $emi =  isset($getplan['emi']) ? $getplan['emi'] : '';
	  $total_months =  isset($getplan['total_months']) ? $getplan['total_months'] : '';
	  $group_count = isset($getplan['groups_counts']) ? $getplan['groups_counts'] : '';
	  $plan_amount = isset($getplan['plan_amount']) ? $getplan['plan_amount'] : '';
	  $tenure = isset($getplan['tenure']) ? $getplan['tenure'] : '';
	  $agent_commission = isset($getplan['agent_commission']) ? $getplan['agent_commission'] : '';
	  $months_completed = isset($getplan['months_completed']) ? $getplan['months_completed'] : '';
	  $end_date_for_subscription = isset($getplan['end_date_for_subscription']) ? $getplan['end_date_for_subscription'] : '';
	   
	  if(!empty($agent_id)){
	     $is_added_by_agent = 1;
	  }else{
	     $is_added_by_agent = 0; 
	  }
	  
	 $group_data = $this->db->select('group_id,total_members')->where('plan_id',$plan_id)->get('tbl_groups')->result_array();
	 if(!empty($group_data)){
	 $test = false;
	 foreach($group_data as $key => $value){
	  $group_id = isset($value['group_id']) ? $value['group_id'] : '';
	  $group_data1 = $this->db->where('plan_id',$plan_id)->where('group_id',$group_id)->get('tbl_orders')->result_array();
	  if(!empty($group_data1)){
	  foreach($group_data1 as $key1 => $value1){
	      $slot_status = isset($value1['slot_status']) ? $value1['slot_status'] : '';
	      $order_id = isset($value1['order_id']) ? $value1['order_id'] : '';
    	      if($slot_status == 'vacant'){
	          $data = array(
	            'member_id' => isset($member_id) ? $member_id : '',
				'plan_id'   => isset($plan_id) ? $plan_id : '',
				'group_id'  => isset($group_id) ? $group_id : '',
				'member_name' => isset($member_name) ? $member_name : '',
				'plan_amount' => isset($plan_amount) ? $plan_amount : '',
				'start_month' => isset($start_month) ? $start_month : '',
				'emi' => isset($emi) ? $emi : '',
				'tenure' => isset($tenure) ? $tenure : '',
				'months_completed' => isset($months_completed) ? $months_completed : '',
				'agent_commission' => isset($agent_commission) ? $agent_commission : '',
				'end_month' => isset($end_date_for_subscription) ? $end_date_for_subscription : '',
				'total_months' => isset($total_months) ? $total_months : '',
				'groups_count'  => isset($group_count) ? $group_count : '',
				'admission_fees'    => isset($admission_fees) ? $admission_fees : '',
				'agent_id'  => isset($agent_id) ? $agent_id : '',
				'is_added_by_agent' => $is_added_by_agent,
				'transaction_id' => isset($transaction_id) ? $transaction_id : '',
				'payment_mode' => isset($payment_mode) ? $payment_mode : '',
				'slot_status' => 'Assigned',
				'added_date' => date('Y-m-d h:i:s')
	          );
	          $this->db->where('plan_id',$plan_id)->where('group_id',$group_id)->where('order_id',$order_id)->update('tbl_orders',$data);
	         
	          //Emi
			  $getorder =  $this->db->where('order_id',$order_id)->get('tbl_orders')->row_array();
			  $months = explode(" ",$getorder['tenure']);
			  $getmonths = isset($months[0]) ? $months[0] : ''; 
			  
			  $date2 = date('m', strtotime($start_month));
			  $date2 = 0;
			  $emi = round($emi, 0);
			  for($i=1; $i<=$getmonths; $i++){
				 // one column add in emi table plan name (pending)
				$date3 = date('M', strtotime($start_month. ' + '.$date2.'month'));
				$date2  = $date2 + 1; 
				$data1 = array(
				'member_id' => isset($member_id) ? $member_id : '',
				'plan_id'   => isset($plan_id) ? $plan_id : '',
				'group_id'  => isset($group_id) ? $group_id : '',
				'emi_month' => $date3,
				'plan_emi' => $emi,
				'emi_no' => $i,
				'total_emi' => $tenure,
				'emi_status'  => "due",
				'is_partial_payment' => "No",
				'is_chit_taken' => "no",
				'chit_status' => 'close',
				'added_date' => date('Y-m-d h:i:s')
			   );
			   $this->db->insert('tbl_emi',$data1);
			   $insert_id1 = $this->db->insert_id();
			   if(!empty($insert_id1)){
					$output = array(
						'status' => Success,
						'message' => 'Save Order Successfully',
						'data' => [],
					);	 
			   }else{
				  $output = array(
						'status' => Failure,
						'message' => "Invalid Data.",
						'data' => []
					); 
				}
			 }
	         $test = true;
	          break;
	      }
	      else{
	        $output = array(
				'status' => Success,
				'message' => "All Order Slot Booked",
				'data' => []
			  ); 
	        continue;
	      }
 	    }
 	    if($test == true){
 	        break;
 	    }else{
 	        continue;
 	    }
	   }else{
	     $output = array(
			'status' => Failure,
			'message' => "Data not found order table",
			'data' => []
		  );   
	   }
	  }
	 }else{
	     $output = array(
    		'status' => Failure,
    		'message' => "Data not found Group table",
    		'data' => []
    	  ); 
	 }
	  echo json_encode($output); die;
	}
	
	public function closeAuctionAutomatically(){ //17jan2022
			$date = date('m/d/Y');
			$time = date('H:i:s');	
			$auction_detail = $this->db->where('status','1')->where('end_date',$date)->get('tbl_auction')->result_array();
			foreach($auction_detail as $keys=>$values){
				$endtime=$values['end_time'];
				$auction_id = $values['auction_id'];
				if($time>$endtime){					
						$auction_status = array(
							'status' => '0'
						);
					$update = $this->db->where('auction_id',$auction_id)->update('tbl_auction',$auction_status);
					$auction_detail = $this->db->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
					$plan_id =  $auction_detail['plan_id'];
					$group_id = $auction_detail['group_id'];
					$return_chit_amount = $auction_detail['plan_amount'];
					$bid_id = $auction_detail['winning_bid_id'];
					
					$total_amount_paid = '0';
					$is_on_EMI = 'yes';				
					$bid_detail = $this->db->select('bid_amount')->where('auction_id',$auction_id)->get('tbl_bids')->result_array();
					$array_new = array();
					foreach($bid_detail as $keys=>$values){
						$array_new[] = $values['bid_amount'];
					}
					$min_bid = min($array_new);
					$bid_id = $this->db->select('bid_id')->where('auction_id',$auction_id)->where('bid_amount',$min_bid)->get('tbl_bids')->row_array();
					$min_bid_id = $bid_id['bid_id'];				
					$winning_bid_id = array(
						'winning_bid_id'=> isset($min_bid_id) ? $min_bid_id  : '',
					);
					$winning_id_update = $this->db->where('auction_id',$auction_id)->update('tbl_auction',$winning_bid_id);
					$bid_data = $this->db->where('bid_id',$min_bid_id)->get('tbl_bids')->row_array();
					$chit_amount = $bid_data['bid_amount'];
					$member_id = $bid_data['member_id'];
					$plan_id = $bid_data['plan_id'];
					$plan_details = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
					$total_amount_due = $plan_details['plan_amount'];
					$plan_tenure = $plan_details['tenure'];
					$plan_months_completed = $plan_details['months_completed'];
					$remaining_month = $plan_details['remaining_month'];
					$emiamountupdate = array(
						'months_completed' => $plan_months_completed+1,
						'remaining_month' => $remaining_month-1
					);
					$this->db->where('plan_id',$plan_id)->update('tbl_plans',$emiamountupdate);
					$forgo_amount = $total_amount_due - $chit_amount;
					$emi_amount = ($total_amount_due / ($plan_tenure-$plan_months_completed));
					$total_emi = $plan_tenure - $plan_months_completed;//
					$due_emi = $plan_tenure - $plan_months_completed;
					$emi_paid = '0';
					$is_active = '1';
					
					$data = array(
						'plan_id' => isset($plan_id) ? $plan_id : '',//
						'group_id' =>  isset($group_id) ? $group_id : '',//
						'auction_id' =>  isset($auction_id) ? $auction_id : '',//
						'member_id' =>  isset($member_id) ? $member_id : '',//
						'return_chit_amount' =>  isset($return_chit_amount) ? $return_chit_amount : '',//
						'total_amount_paid' => isset($total_amount_paid) ? $total_amount_paid : '',//
						'total_amount_due' => isset($total_amount_due) ? $total_amount_due : '',//
						'chit_amount' => isset($chit_amount) ? $chit_amount : '',//
						'forgo_amount' => isset($forgo_amount) ? $forgo_amount : '',//
						'is_on_EMI' => isset($is_on_EMI) ? $is_on_EMI : '',//
						'emi_amount' => isset($emi_amount) ? $emi_amount : '',//
						'total_emi' => isset($total_emi) ? $total_emi : '',//
						'due_emi' => isset($due_emi) ? $due_emi : '',//
						'emi_paid' => isset($emi_paid) ? $emi_paid : '',//
						'is_active' => isset($is_active) ? $is_active : '',	//	 
					); 			
					 $emi_amount = round($emi_amount, 0);
					 $chit_emi_months = $plan_months_completed+1;
					$insertdata = $this->db->insert('tbl_chits',$data);
					for($i=1; $i<=$total_emi; $i++){
						$data2 = array(
							'plan_id' => isset($plan_id) ? $plan_id : '',//
							'member_id' => isset($member_id) ? $member_id : '',//
							'group_id' => isset($group_id) ? $group_id : '',//
							'emi_no' => $i,//
							'chit_emi' => isset($emi_amount) ? $emi_amount : '',//
							'total_emi' => isset($total_emi) ? $total_emi : '',//
							'emi_status' => 'due',//
							'chit_amount' => isset($chit_amount) ? $chit_amount : '',
							'return_chit_amount' => isset($return_chit_amount) ? $return_chit_amount : '',//
							'return_factor' => '0',//
							'chit_emi_months' => isset($chit_emi_months) ? $chit_emi_months : '',//
							'is_partial_payment' => 'No'
						);
				// 			$insert_chit_emi = $this->db->insert('chit_emi',$data2);
							$chit_emi_months++;
					}
					$win_bid_acc = array(
						'is_bid_accepted'=>'yes'
					);
					$this->db->where('bid_id',$min_bid_id)->update('tbl_bids',$win_bid_acc);
					$member_name_detail = $this->db->select('name')->where('member_id',$member_id)->get('tbl_members')->row_array();
							$member_name = $member_name_detail['name'];
							$foreman_fees_detail = $this->db->select('foreman_fees,total_months')->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
							$foreman_fees = $foreman_fees_detail['foreman_fees'];
							$total_months = $foreman_fees_detail['total_months'];
							$group_details_member = $this->db->select('total_members')->where('group_id',$group_id)->get('tbl_groups')->row_array(); 
							$group_member = $group_details_member['total_members'];
							$forman_amount = $total_amount_due*$foreman_fees/100;
							$divident_amount = ($total_amount_due -($chit_amount + $forman_amount)) / $group_member;	
							$divident_data = array(
								'member_name'=>isset($member_name) ? $member_name : '',
								'member_id'=>isset($member_id) ? $member_id : '',
								'plan_id'=>isset($plan_id) ? $plan_id : '',
								'group_id'=>isset($group_id) ? $group_id : '',
								'auction_id'=>$auction_id,
								'divident_amount'=>$divident_amount,
								'month'=>isset($auction_no) ? $auction_no : '',
								'total_months'=>isset($total_months) ? $total_months : '',		
							);
							$dividint_months_sub = $plan_months_completed+1;
								$this->db->insert('tbl_divident',$divident_data);
								$emidivident = array(
									'divident' => $divident_amount
								);
								$this->db->where('emi_no',$dividint_months_sub)->where('member_id',$member_id)->where('plan_id',$plan_id)->update('tbl_emi',$emidivident);
								
					$output = array(
						'success'=>'success',
						'message'=>'auction close',	
						'winning bid id'=>$min_bid_id,			
						'auction_id'=>$auction_id
					);
					echo json_encode($output);die;
				}			
				
			}			
		}
		
		
	

   	public function plangroupsforauction(){ //12jan2022 ..update
		$data =  json_decode($this->data);
	    $plan_id = $data->plan_id; 
		$getgroup = $this->db->where('plan_id',$plan_id)->get('tbl_groups')->result_array();
	    $all_detail = array();
	    $new_arr = array();
	    $getgrouprowData = [];
	    $auctionData = [];
		
		foreach($getgroup as $keys => $values){
			$group_id = $values['group_id'];			
			$auction_detail = $this->db->select('auction_no,status,auction_id')->where('plan_id',$plan_id)->where('group_id',$group_id)->order_by('auction_id','desc')->get('tbl_auction')->row_array();
			$getgrouprow = $this->db->where('plan_id',$plan_id)->where('group_id',$group_id)->get('tbl_groups')->row_array();	
			$plan_detail = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
			$auctionData[$keys] = $auction_detail;
			$getgrouprowData[$keys] = $getgrouprow;
			$plan_amount = $plan_detail['plan_amount'];
			$forman_fees = $plan_detail['foreman_fees'];
			$forman_amount = $plan_amount*$forman_fees/100;
			$all_detail[$keys]['auction_no']  =   isset($auction_detail['auction_no']) ?  $auction_detail['auction_no'] : '' ;
			$all_detail[$keys]['status']      =  isset($auction_detail['status']) ?  $auction_detail['status'] : '' ;
			$all_detail[$keys]['auction_id']  =  isset($auction_detail['auction_id']) ? $auction_detail['auction_id'] : '' ;
			$all_detail[$keys]['group_id']    =  isset($getgrouprow['group_id']) ?  $getgrouprow['group_id'] : '' ;
			$all_detail[$keys]['forman_fees'] =  isset($forman_amount)  ? $forman_amount : '';
			$all_detail[$keys]['plan_id']     =  isset($getgrouprow['plan_id']) ? $getgrouprow['plan_id'] : '';
			$all_detail[$keys]['total_members']= isset($getgrouprow['total_members']) ? $getgrouprow['total_members'] : '';
			$all_detail[$keys]['group_name'] =   isset($getgrouprow['group_name']) ? $getgrouprow['group_name'] : '' ;
			$all_detail[$keys]['plan_id']    =   isset($getgrouprow['plan_id']) ? $getgrouprow['plan_id'] : '';
			$all_detail[$keys]['group_name'] =   isset($getgrouprow['group_name'])  ? $getgrouprow['group_name'] : '' ;
			$all_detail[$keys]['added_date'] =   isset($getgrouprow['added_date']) ? $getgrouprow['added_date'] : '' ;
			$all_detail[$keys]['update_date']=   isset($getgrouprow['update_date'])  ? $getgrouprow['update_date'] : '';			
		}		       
		if(!empty($getgroup)){
			$output = array(
				'status' => Success,
				'message' => 'Group Details Fetched Successfully',
			    'data' => $all_detail,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}	
	public function getbidsforauction(){ // 10jan2022
		$data =  json_decode($this->data);
		$auction_id = isset($data->auction_id) ? $data->auction_id : ''; 
		$getauction = $this->db->where('auction_id',$auction_id)->get('tbl_bids')->result_array();
		if(!empty($getauction)){
			$output = array(
				'status' => Success,
				'message' => 'Bids Details Fetched Successfully',
			    'data' => $getauction,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "No Data Found Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
	public function getchitemi(){ // 10jan2022
		$data =  json_decode($this->data);
		$member_id = $data->member_id; 
		$plan_id_detail = $this->db->where('member_id',$member_id)->get('chit_emi')->row_array();
		$plan_id = $plan_id_detail['plan_id'];
		$plan_detail = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
		$months_completed = $plan_detail['months_completed'];		
		$new_arr = array();
		for ($i=1; $i<=$months_completed; $i++){
			$getchitemi = $this->db->where('emi_status','due')->where('chit_emi_months',$i)->where('member_id',$member_id)->get('chit_emi')->result_array();			
			$new_arr[] = $getchitemi;
		}
		$newarray = array();
		foreach($new_arr as $key=>$value){
			foreach( $value as $keys=>$values ){
			  $newarray[] = $values['chit_emi_id'];
			}			
		}
		$newchitarray = array();
		foreach( $newarray as $key=>$values){
			$getchit = $this->db->where('chit_emi_id',$values)->get('chit_emi')->row_array();
			$newchitarray[] = $getchit;
		}

		if(!empty($newchitarray)){
			$output = array(
				'status' => Success,
				'message' => 'Chit Emi Details Fetched Successfully',
			    'data' => $newchitarray,
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "No Data Found Data.",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}

     public function getsubscriberdues(){		
		$data =  json_decode($this->data);
		$member_id = $data->member_id; 
		$plan_id_emi_detail = $this->db->where('member_id',$member_id)->get('tbl_emi')->row_array();
	
		if(!empty($plan_id_emi_detail)){
		    	$plan_id = $plan_id_emi_detail['plan_id'];
        		$plan_detail = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
        		$months_completed = $plan_detail['months_completed'];		
        		$new_arr = array();
        		for ($i=1; $i<=$months_completed; $i++){
        			$getchitemi = $this->db->where('emi_status','due')->where('emi_no',$i)->where('member_id',$member_id)->get('tbl_emi')->result_array();			
        			$new_arr[] = $getchitemi;
        		}
        		    
        		    $newarray = array();
        		foreach($new_arr as $key=>$value){
        			foreach( $value as $keys=>$values ){
        			  $newarray[] = $values['emi_id'];
        			}			
        		}
        		$rowofemidue =  count($newarray);
        		$sumofemidues = 0;
        		foreach( $newarray as $key=>$values){			
        			$getchitemidue = $this->db->select('plan_emi')->where('emi_id',$values)->where('is_partial_payment','No')->where('emi_status','due')->get('tbl_emi')->row_array();
        			$plan_emi = isset($getchitemidue['plan_emi']) ? $getchitemidue['plan_emi'] : '' ;	
        			if($plan_emi != ''){
        			  $sumofemidues+= $plan_emi;
        			}else{
        				$sumofemidues += 0;	
        			}	
        		}
        		$sumpartialemi = 0;
        		foreach( $newarray as $key=>$values){
        			$getchitempartialidue = $this->db->select('amount_due')->where('emi_id',$values)->where('is_partial_payment','Yes')->where('emi_status','due')->get('tbl_emi')->row_array();				
        			$partial_emi = isset($getchitempartialidue['amount_due']) ? $getchitempartialidue['amount_due'] : '' ;		
        			if($partial_emi != ''){
        				$sumpartialemi+= $partial_emi;
        			  }else{
        				  $sumpartialemi += 0;	
        			  }	
        		}
		$total_plan_amount_due = $sumpartialemi + $sumofemidues;
		}
		
		$plan_id_detail = $this->db->where('member_id',$member_id)->get('chit_emi')->row_array();
		if(!empty($plan_id_detail)){
		    $plan_id = $plan_id_detail['plan_id'];
		$plan_detail = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
		$months_completed = $plan_detail['months_completed'];		
		$new_arr = array();
		for ($i=1; $i<=$months_completed; $i++){
			$getchitemi = $this->db->where('emi_status','due')->where('chit_emi_months',$i)->where('member_id',$member_id)->get('chit_emi')->result_array();			
			$new_arr[] = $getchitemi;
		}
		$newarray2 = array();
		foreach($new_arr as $key=>$value){
			foreach( $value as $keys=>$values ){
			  $newarray2[] = $values['chit_emi_id'];
			}			
		}
		$sumofchitemidues = 0;
		foreach( $newarray2 as $key=>$values){			
			$getchitemidue = $this->db->select('chit_emi')->where('chit_emi_id',$values)->where('is_partial_payment','No')->where('emi_status','due')->get('chit_emi')->row_array();
			$plan_emi = isset($getchitemidue['chit_emi']) ? $getchitemidue['chit_emi'] : '' ;	
			if($plan_emi != ''){
			  $sumofchitemidues+= $plan_emi;
			}else{
				$sumofchitemidues += 0;	
			}	
		}
		$sumchitpartialemi = 0;
		foreach( $newarray as $key=>$values){
			$getchitempartialidue = $this->db->select('amount_due')->where('chit_emi_id',$values)->where('is_partial_payment','Yes')->where('emi_status','due')->get('chit_emi')->row_array();				
			$partial_emi = isset($getchitempartialidue['amount_due']) ? $getchitempartialidue['amount_due'] : '' ;		
			if($partial_emi != ''){
				$sumchitpartialemi+= $partial_emi;
			  }else{
				  $sumchitpartialemi += 0;	
			  }	
		}
		$total_chit_amount_due =  $sumchitpartialemi + $sumofchitemidues;
		$rowschitemi =  count($newarray2);
		}
		
		

		$data = array(
					 'emi_due' =>  isset( $rowofemidue) ? $rowofemidue :''	, 
					 'emi_total_due_amount' => isset( $total_plan_amount_due) ? $total_plan_amount_due :'0'	, 
					 'chit_emi_due' =>  isset($rowschitemi) ? $rowschitemi :'0'	, 
					 'chit_emi_total_due_amount' =>  isset($total_chit_amount_due) ? $total_chit_amount_due :'0',
					 'additional_dues' => 0,
					 'registration_dues' => 0
					);
					
					if(! empty($total_plan_amount_due) || ! empty($total_chit_amount_due)){
						$output = array(
							'status' => Success,
							'message' => 'Chit Emi Details Fetched Successfully',
						    'data' => $data
			            );	
					}else{
						$output = array(
							'status' => Failure,
							'message' => "No Data Found Data.",
							'data' => []
			            );
					}
					echo json_encode($output);die;
			

	
	}



   public function assignChits(){ //11jan2022  update ..
	$data =  json_decode($this->data);
	$auction_id = $data->auction_id; 
	 
	 $auction_details = $this->db->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
	 $plan_id =  $auction_details['plan_id'];
	 $auction_no =  $auction_details['auction_no'];
	 $group_id = $auction_details['group_id'];
	 $return_chit_amount = $auction_details['plan_amount'];
	 $bid_id = $auction_details['winning_bid_id'];
	 $bid_detail = $this->db->where('bid_id',$bid_id)->get('tbl_bids')->row_array();
	 $chit_amount = $bid_detail['bid_amount'];
	 $member_id = $bid_detail['member_id'];
	 $total_amount_paid = '0';
	 $is_on_EMI = 'yes';
	
	 $plan_details = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
	 $total_amount_due = $plan_details['plan_amount'];
	 $plan_tenure = $plan_details['tenure'];
	 $plan_months_completed = $plan_details['months_completed'];
	 $forgo_amount = $total_amount_due - $chit_amount;
	 $emi_amount = ($total_amount_due / ($plan_tenure-$plan_months_completed));
	 $total_emi = $plan_tenure - $plan_months_completed;
	 $due_emi = $plan_tenure - $plan_months_completed;
	 $emi_paid = '0';
	 $is_active = '1';
	
	 $data = array(
		 'plan_id' => isset($plan_id) ? $plan_id : '',//
		 'group_id' =>  isset($group_id) ? $group_id : '',//
		 'return_chit_amount' =>  isset($return_chit_amount) ? $return_chit_amount : '',//
		 'total_amount_paid' => isset($total_amount_paid) ? $total_amount_paid : '',//
		 'total_amount_due' => isset($total_amount_due) ? $total_amount_due : '',//
		 'chit_amount' => isset($chit_amount) ? $chit_amount : '',//
		 'forgo_amount' => isset($forgo_amount) ? $forgo_amount : '',//
		 'is_on_EMI' => isset($is_on_EMI) ? $is_on_EMI : '',//
		 'emi_amount' => isset($emi_amount) ? $emi_amount : '',//
		 'total_emi' => isset($total_emi) ? $total_emi : '',//
		 'due_emi' => isset($due_emi) ? $due_emi : '',//
		 'emi_paid' => isset($emi_paid) ? $emi_paid : '',//
		 'is_active' => isset($is_active) ? $is_active : '',	//	 
	 ); 

	$emi_amount = round($emi_amount, 0);
	  for($i=1; $i<=$total_emi; $i++){
		$data2 = array(
			'plan_id' => isset($plan_id) ? $plan_id : '',//
			'member_id' => isset($member_id) ? $member_id : '',//
			'group_id' => isset($group_id) ? $group_id : '',//
			'emi_no' => $i,//
			'chit_emi' => isset($emi_amount) ? $emi_amount : '',//
			'total_emi' => isset($total_emi) ? $total_emi : '',//
			'emi_status' => 'due',//
			'chit_amount' => isset($chit_amount) ? $chit_amount : '',
			'return_chit_amount' => isset($return_chit_amount) ? $return_chit_amount : '',//
			'return_factor' => '0',//
			'chit_emi_months' => isset($due_emi) ? $due_emi : '',//
		 );
	        $insert_chit_emi = $this->db->insert('chit_emi',$data2);
	 }

	 if(!empty($auction_details)){
		$insertdata = $this->db->insert('tbl_chits',$data);
				$member_name_detail = $this->db->select('name')->where('member_id',$member_id)->get('tbl_members')->row_array();
				$member_name = $member_name_detail['name'];
				$foreman_fees_detail = $this->db->select('foreman_fees,total_months')->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
				$foreman_fees = $foreman_fees_detail['foreman_fees'];
				$total_months = $foreman_fees_detail['total_months'];
				$group_details_member = $this->db->select('total_members')->where('group_id',$group_id)->get('tbl_groups')->row_array(); 
				$group_member = $group_details_member['total_members'];
				$divident_amount = ($total_amount_due -($chit_amount + $foreman_fees)) / $group_member;	
				$divident_data = array(
					'member_name'=>isset($member_name) ? $member_name : '',
					'member_id'=>isset($member_id) ? $member_id : '',
					'plan_id'=>isset($plan_id) ? $plan_id : '',
					'group_id'=>isset($group_id) ? $group_id : '',
					'auction_id'=>$auction_id,
					'divident_amount'=>$divident_amount,
					'month'=>isset($auction_no) ? $auction_no : '',
					'total_months'=>isset($total_months) ? $total_months : '',		
				);
					$this->db->insert('tbl_divident',$divident_data);

		if(!empty($auction_details)){
			$output = array(
				'status' => Success,
				'message' => 'Insert Chit Successfully',
				'data' => $insertdata,
			);	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
		); 
	    }
	 }
	 else{
		$output = array(
			'status' => Failure,
			'message' => "NO Data Found.",
			'data' => []
	       ); 
	 }	 
	echo json_encode($output);die;
 	}
	
    	public function savefinalbid(){		//17jan2022
		$data =  json_decode($this->data);
		$bid_id = isset($data->bid_id) ? $data->bid_id : '';
		$bid_detial = $this->db->where('bid_id',$bid_id)->get('tbl_bids')->row_array();		
		if(!empty($bid_detial)){
		$auction_id = isset($bid_detial['auction_id']) ? $bid_detial['auction_id'] : '';
		$plan_id = isset($bid_detial['plan_id']) ? $bid_detial['plan_id'] : '';
		$bid_amount = isset($bid_detial['bid_amount']) ? $bid_detial['bid_amount'] : '';
		$member_id = isset($bid_detial['member_id']) ? $bid_detial['member_id'] : '';
		$group_id = isset($bid_detial['group_id']) ? $bid_detial['group_id'] : '';
		$data = array(
			'winning_bid_id' => $bid_id,
			'status'=>'0'
		);
		$auction_update = $this->db->where('auction_id',$auction_id)->update('tbl_auction',$data);	
		$auction_detail = $this->db->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
		$return_chit_amount = isset($auction_detail['plan_amount']) ? $auction_detail['plan_amount'] : '';	
		$auction_no = isset($auction_detail['auction_no']) ? $auction_detail['auction_no'] : '';	
		$plan_details = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
				$total_amount_due = isset($plan_details['plan_amount']) ? $plan_details['plan_amount'] : '';
				$total_amount_paid = '0';
				$is_on_EMI = 'yes';	
				$plan_tenure = isset($plan_details['tenure']) ? $plan_details['tenure'] : '';
				$plan_months_completed = isset($plan_details['months_completed']) ? $plan_details['months_completed'] : '';
				$emiamountupdate = array(
					'months_completed' => $plan_months_completed+1
				);
				$this->db->where('plan_id',$plan_id)->update('tbl_plans',$emiamountupdate);
				$chit_amount = $bid_detial['bid_amount'];
				$forgo_amount = $total_amount_due - $chit_amount;
				$emi_amount = ($total_amount_due / ($plan_tenure-$plan_months_completed));
				$total_emi = $plan_tenure - $plan_months_completed;//
				$due_emi = $plan_tenure - $plan_months_completed;
				$emi_paid = '0';
				$is_active = '1';
				
				$data = array(
					'plan_id' => isset($plan_id) ? $plan_id : '',//
					'group_id' =>  isset($group_id) ? $group_id : '',//
					'auction_id' =>  isset($auction_id) ? $auction_id : '',//
					'member_id' =>  isset($member_id) ? $member_id : '',//
					'return_chit_amount' =>  isset($return_chit_amount) ? $return_chit_amount : '',//
					'total_amount_paid' => isset($total_amount_paid) ? $total_amount_paid : '',//
					'total_amount_due' => isset($total_amount_due) ? $total_amount_due : '',//
					'chit_amount' => isset($chit_amount) ? $chit_amount : '',//
					'forgo_amount' => isset($forgo_amount) ? $forgo_amount : '',//
					'is_on_EMI' => isset($is_on_EMI) ? $is_on_EMI : '',//
					'emi_amount' => isset($emi_amount) ? $emi_amount : '',//
					'total_emi' => isset($total_emi) ? $total_emi : '',//
					'due_emi' => isset($due_emi) ? $due_emi : '',//
					'emi_paid' => isset($emi_paid) ? $emi_paid : '',//
					'is_active' => isset($is_active) ? $is_active : '',	//	 
				); 			
				 $emi_amount = round($emi_amount, 0);
				 $chit_emi_months = $plan_months_completed+1;
				$insertdata = $this->db->insert('tbl_chits',$data);
				for($i=1; $i<=$total_emi; $i++){
					$data2 = array(
						'plan_id' => isset($plan_id) ? $plan_id : '',//
						'member_id' => isset($member_id) ? $member_id : '',//
						'group_id' => isset($group_id) ? $group_id : '',//
						'emi_no' => $i,//
						'chit_emi' => isset($emi_amount) ? $emi_amount : '',//
						'total_emi' => isset($total_emi) ? $total_emi : '',//
						'emi_status' => 'due',//
						'chit_amount' => isset($chit_amount) ? $chit_amount : '',
						'return_chit_amount' => isset($return_chit_amount) ? $return_chit_amount : '',//
						'return_factor' => '0',//
						'chit_emi_months' => isset($chit_emi_months) ? $chit_emi_months : '',//
						'is_partial_payment' => 'No'
					);
						// $insert_chit_emi = $this->db->insert('chit_emi',$data2);
						$chit_emi_months++;
				}
				$win_bid_acc = array(
					'is_bid_accepted'=>'yes'
				);
				$this->db->where('bid_id',$bid_id)->update('tbl_bids',$win_bid_acc);				
				$member_name_detail = $this->db->select('name')->where('member_id',$member_id)->get('tbl_members')->row_array();
						$member_name = $member_name_detail['name'];
						$foreman_fees_detail = $this->db->select('foreman_fees,total_months')->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
						$foreman_fees = $foreman_fees_detail['foreman_fees'];
						$total_months = $foreman_fees_detail['total_months'];
						$group_details_member = $this->db->select('total_members')->where('group_id',$group_id)->get('tbl_groups')->row_array(); 
						$group_member = $group_details_member['total_members'];
						$forman_amount = $total_amount_due*$foreman_fees/100;
						$divident_amount = ($total_amount_due -($chit_amount + $forman_amount)) / $group_member;	
						$divident_data = array(
							'member_name'=>isset($member_name) ? $member_name : '',
							'member_id'=>isset($member_id) ? $member_id : '',
							'plan_id'=>isset($plan_id) ? $plan_id : '',
							'group_id'=>isset($group_id) ? $group_id : '',
							'auction_id'=>$auction_id,
							'divident_amount'=>$divident_amount,
							'month'=>isset($auction_no) ? $auction_no : '',
							'total_months'=>isset($total_months) ? $total_months : '',		
						);
						$dividint_months_sub = $plan_months_completed+1;
							$this->db->insert('tbl_divident',$divident_data);
							$emidivident = array(
								'divident' => $divident_amount
							);
							$this->db->where('emi_no',$dividint_months_sub)->where('member_id',$member_id)->where('plan_id',$plan_id)->update('tbl_emi',$emidivident);
				
			$output = array(
				'status' => Success,
				'message' => 'Final bid set successfully.Now auction has been closed and No more bid will be accepted ',
			    'data' => []
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "failed",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}	
	
	public function cancelAuction(){		//11jan2022 new
		$data =  json_decode($this->data);
		$auction_id = isset($data->auction_id) ? $data->auction_id : '';
		$data = array(
			'status' => '3'
		);
		$sql = $this->db->where('auction_id',$auction_id)->update('tbl_auction',$data);
		$chit_detail = $this->db->where('auction_id',$auction_id)->get('tbl_chits')->row_array();
		if(!empty($chit_detail)){
			$group_id = isset($chit_detail['group_id']) ? $chit_detail['group_id'] : '';
			$plan_id = isset($chit_detail['plan_id']) ? $chit_detail['plan_id'] : '';
			$member_id = isset($chit_detail['member_id']) ? $chit_detail['member_id'] : '';
			$this->db->where('group_id',$group_id)->where('member_id',$member_id)->where('plan_id',$plan_id)->delete('chit_emi');
			$sqlsql = $this->db->where('auction_id',$auction_id)->delete('tbl_chits');
		}
		if(!empty($sqlsql)){
			$output = array(
				'status' => Success,
				'message' => 'Auction cancelled Successfully',
			    'data' => []
            );	
		}else{
			$output = array(
				'status' => Failure,
				'message' => "failed",
				'data' => []
            );
		}
		echo json_encode($output);die;
	}
	
	
	
	public function payDues(){
		$data =  json_decode($this->data,true);	
		$emi_ids = array();
		$total_amounts = array();
		$new_status = array();
		foreach ($data as $keys=>$values){			
			$emi_id = isset( $values['id']) ? $values['id'] :''	;		
			$emi_amount=  isset( $values['amount']) ? $values['amount'] :'' ;
			$status = isset( $values['status']) ? $values['status'] :'';
			$new_status[] =  $status;
			$agent_id = isset( $values['agent_id']) ? $values['agent_id'] :'';
			$payment_mode = isset( $values['payment_mode']) ? $values['payment_mode'] :'';
			$bank_account_id = isset( $values['bank_account_id']) ? $values['bank_account_id'] :'';
			$cheque_number = isset( $values['cheque_number']) ? $values['cheque_number'] :'';
			$Payment_Proof = isset( $values['Payment_Proof']) ? $values['Payment_Proof'] :'';
			if($status == 'chit_emi'){
				$data = $this->db->where('chit_emi_id',$emi_id)->get('chit_emi')->row_array();
				if(!empty($emi_id)){
					if($data['emi_status'] == 'due'){
						if($data['chit_emi'] == $emi_amount){
							$update_status = array(
							'emi_status' =>'paid'
						);
						$update1 = $this->db->where('chit_emi_id',$emi_id)->update('chit_emi',$update_status);
						$member_id = $this->db->select('member_id,plan_id')->where('chit_emi_id',$emi_id)->get('chit_emi')->row_array();
					    $plan_name = $this->db->select('plan_name')->where('plan_id',$member_id['plan_id'])->get('tbl_plans')->row_array();
						$emi_ids[] = $emi_id;
						$total_amounts[] = $emi_amount;
								$output = array(
									'status'=>'success',
									'message'=>'payed emi successfully',
									'data'=>$status
								);		
						}
						elseif($data['emi_status']>$emi_amount){
							if($data['is_partial_payment']=='Yes'){
								$partial_pay_amount = $data['partial_paid_amount']+$emi_amount;
								$partial_due_amount = $data['amount_due']-$emi_amount;
							    $partial_pay_amount = round($partial_pay_amount, 0);
							    $partial_due_amount = round($partial_due_amount, 0);
								$partial_update = array(
									'partial_paid_amount'=>$partial_pay_amount,
									'amount_due'=>$partial_due_amount
								);
								$update_data = $this->db->where('chit_emi_id',$emi_id)->update('chit_emi',$partial_update);
									$this->db->where('chit_emi_id',$emi_id)->update('chit_emi',$data);
    								$member_id = $this->db->select('member_id,plan_id')->where('chit_emi_id',$emi_id)->get('chit_emi')->row_array();
    								$plan_name = $this->db->select('plan_name')->where('plan_id',$member_id['plan_id'])->get('tbl_plans')->row_array();
    								$emi_ids[] = $emi_id;
    								$total_amounts[] = $emi_amount;

								$output = array(
									'status'=>'success',
									'message'=>'Partial Payment Successfull',
									'data'=>$emi_id.','.'chit_emi'
								);

							}else{
								$partial_paid_amount = $data['chit_emi'] - $emi_amount;
								 $partial_paid_amount = round($partial_paid_amount, 0);
							    $emi_amount = round($emi_amount, 0);
								$data = array(
									'is_partial_payment'=>'Yes',
									'amount_due'=>$partial_paid_amount,
									'partial_paid_amount'=>$emi_amount
								);
								$this->db->where('chit_emi_id',$emi_id)->update('chit_emi',$data);
								$member_id = $this->db->select('member_id,plan_id')->where('chit_emi_id',$emi_id)->get('chit_emi')->row_array();
								$plan_name = $this->db->select('plan_name')->where('plan_id',$member_id['plan_id'])->get('tbl_plans')->row_array();
								$emi_ids[] = $emi_id;
								$total_amounts[] = $emi_amount;

								$output = array(
									'status'=>'success',
									'message'=>'Partial Payment Successfull',
									'data'=>$emi_id.','.'chit_emi'
								);
							}							
						}else{
							$output = array(
								'status'=>'Failure',
								'message'=>'Amount not Correct',
								'data'=>$emi_id.','.'chit_emi'
							);
						}
					}
					elseif($data['emi_status'] == 'paid'){
						$output = array(
							'status' => 'Failure',
							'message' => 'This emi already paid',
							'data'=>$emi_id.','.'chit_emi'
						);
					}
				}
			}			
		  
		  	if($status == 'plan_emi'){
			$data = $this->db->where('emi_id',$emi_id)->get('tbl_emi')->row_array();
			if(!empty($emi_id)){
				if($data['emi_status'] == 'due'){
					if($data['plan_emi'] == $emi_amount){
						$update_status = array(
						'emi_status' =>'paid'
					);
					$update2 = $this->db->where('emi_id',$emi_id)->update('tbl_emi',$update_status);
					$member_id = $this->db->select('member_id,plan_id')->where('emi_id',$emi_id)->get('tbl_emi')->row_array();
					$plan_name = $this->db->select('plan_name')->where('plan_id',$member_id['plan_id'])->get('tbl_plans')->row_array();
						$emi_ids[] = $emi_id;
						$total_amounts[] = $emi_amount;

					$output = array(
						'status'=>'success',
						'message'=>'Dues Paid Successfully',
						'data'=>$emi_id.','.'plan_emi'
					);
					
					}
					elseif($data['plan_emi']>$emi_amount){
						if($data['is_partial_payment']=='Yes'){
							$partial_pay_amount = $data['partial_paid_amount']+$emi_amount;
							$partial_due_amount = $data['amount_due']-$emi_amount;
							 $partial_pay_amount = round($partial_pay_amount, 0);
							    $partial_due_amount = round($partial_due_amount, 0);
							$partial_update = array(
								'partial_paid_amount'=>$partial_pay_amount,
								'amount_due'=>$partial_due_amount
							);
							$update_data = $this->db->where('emi_id',$emi_id)->update('tbl_emi',$partial_update);
							$member_id = $this->db->select('member_id,plan_id')->where('emi_id',$emi_id)->get('tbl_emi')->row_array();
							$plan_name = $this->db->select('plan_name')->where('plan_id',$member_id['plan_id'])->get('tbl_plans')->row_array();
							$emi_ids[] = $emi_id;
							$total_amounts[] = $emi_amount;	

						}else{
							$partial_paid_amount = $data['plan_emi'] - $emi_amount;
							 $partial_paid_amount = round($partial_paid_amount, 0);
							 $emi_amount = round($emi_amount, 0);
							$data = array(
								'is_partial_payment'=>'Yes',
								'amount_due'=>$partial_paid_amount,
								'partial_paid_amount'=>$emi_amount
							);
							$this->db->where('emi_id',$emi_id)->update('tbl_emi',$data);
							$member_id = $this->db->select('member_id,plan_id')->where('emi_id',$emi_id)->get('tbl_emi')->row_array();
							$plan_name = $this->db->select('plan_name')->where('plan_id',$member_id['plan_id'])->get('tbl_plans')->row_array();
							$emi_ids[] = $emi_id;
							$total_amounts[] = $emi_amount;							
						}
					}else{
						$output = array(
							'status'=>'Failure',
							'message'=>'Amount not Correct',
							'data'=>$emi_id.','.'plan_emi'
						);
					}
				}
				elseif($data['emi_status'] == 'paid'){
					$output = array(
						'status' => 'Failure',
						'message' => 'This emi already paid',
						'data'=>$emi_id.','.'plan_emi'
					);
				}
			  }						
			}  				
	
		}
		$date = date('d/m/y H:i:s');
		$new_zrr = array();
		$emi_values = implode(',',$emi_ids);
		$sumofdueemi = 0;$i=0;
		foreach($total_amounts as $total_amounts){
			$sumofdueemi+= $total_amounts;	
			$i++;
		}
		if(!empty($agent_id)){
			$is_payment_by_agent = 'yes';
		}
		$histary_data = array(
			'emi_count'=> $i,
			'emi_ids'=>$emi_values,
			'emi_type'=>$new_status[0],
			'transaction_amount'=>$sumofdueemi ,
			'date_time'=>$date,
			'payment_mode'=>'',
			'plan_id'=>isset($member_id['plan_id']) ? $member_id['plan_id'] : '',
			'plan_name'=>isset($plan_name['plan_name']) ? $plan_name['plan_name'] : '',
			'member_id'=> isset($member_id['member_id']) ? $member_id['member_id'] : '',
			'is_payment_by_agent'=> isset($is_payment_by_agent) ? $is_payment_by_agent : 'no',
			'agent_id'=>isset($agent_id) ? $agent_id : '',
			'payment_mode'=>isset($payment_mode) ? $payment_mode : '',
			'bank_account_id'=>isset($bank_account_id) ? $bank_account_id : '',
			'cheque_no'=>isset($cheque_number) ? $cheque_number : '',
			'Payment_Proof'=>isset($Payment_Proof) ? $Payment_Proof : '',
		);
		if(!empty($emi_ids)){
		$this->db->insert('transactions_history',$histary_data);	
		$output = array(
			'status'=>'success',
			'message'=>'Dues Paid Successfully',
			'data'=>$emi_id.','.'plan_emi'
		);	
		echo json_encode($output);die;
		}
		echo json_encode($output);die;
	}
	
	
	public function GetAuctionEndTime(){
		$current_time = date('H:i:s');
		$current_date = date('m/d/Y');
		$time_date = date('d/m/y H:i:s');
		$data =  json_decode($this->data);
	    $auction_id = $data->auction_id;
		$time = $data->time;
		
		if($time =='start_time'){
			$auction_detail = $this->db->select('start_date,start_time')->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
			if(!empty($auction_detail)){
			$start_time = $auction_detail['start_time'];
// 			$start_date = $auction_detail['start_date'];

				$time1 = date_create($start_time);
				$time2 = date_create($current_time);
				$interval = date_diff($time2, $time1);
				$h = $interval->h;
				$i = $interval->i;
				$s = $interval->s;
				// print_r($h.$i.$s);
				$deff_time = array(
					'hour'=>$h,
					'minute'=>$i,
					'second'=>$s
				);

				// $date1 = date_create($start_date);
				// $date2 = date_create($current_date);
				// $interval_d = date_diff($date1, $date2);
				// $d = $interval_d->d;
				// $m = $interval_d->m;
				// $y = $interval_d->y;
				
				$output = array(
					'status'=>'success',
					'message'=>'date fatch successfullt',
					'data'=>array($deff_time)
				);
			    
			}

		}
		elseif($time == 'end_time'){
			$auction_detail = $this->db->select('end_time,end_date')->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
			if(!empty($auction_detail)){
			$end_time = $auction_detail['end_time'];
// 			$end_date = $auction_detail['end_date'];			
				$time1 = date_create($end_time);
				$time2 = date_create($current_time);
				$interval = date_diff($time2,$time1);
				$h = $interval->h;
				$i = $interval->i;
				$s = $interval->s;
				$deff_time = array(
					'hour'=>$h,
					'minute'=>$i,
					'second'=>$s
				);				
				$output = array(
					'status'=>'success',
					'message'=>'fatch successfully',
					'data'=>array($deff_time)
				);
			}			
		}
	       $nodata = array(
					'hour'=>0,
					'minute'=>0,
					'second'=>0
				);
				
		if(empty($auction_detail)){
			$output = array(
				'status'=>'failure',
				'message'=>'found time is not fatched',
				'data'=>array($nodata)
			);
		}
		
		echo(json_encode($output));die;
	}
	
	public function getTransactionsHistory(){
		$data = $this->db->get('transactions_history')->result_array();
		if(!empty($data)){
			$output = array(
				'status'=>'success',
				'message'=>'Transaction history fatch successfull',
				'data'=>$data
			);
		}else{
			$output = array(
				'status'=>'failed',
				'message'=>'No Data Found',
				'data'=>''
			);
		}
		echo json_encode($output);die;
	}
	
	public function getMemberTransactionsHistory(){
		$data =  json_decode($this->data);
	    $member_id = $data->member_id;
		$transaction_data = $this->db->where('member_id',$member_id)->get('transactions_history')->result_array();
		if(!empty($transaction_data)){
			$output = array(
				'status'=>'success',
				'message'=>'Transaction history fatch successfull',
				'data'=>$transaction_data
			);
		}else{
			$output = array(
				'status'=>'failed',
				'message'=>'No Data Found',
				'data'=>''
			);
		}
		echo json_encode($output);die;
	}
	
	public function getTransactionDetails(){
		$data =  json_decode($this->data);
	    $transaction_id = $data->transaction_id;
		$transaction_data = $this->db->select('emi_ids,emi_type,plan_name')->where('transaction_id',$transaction_id)->get('transactions_history')->row_array();
		$emi_values = explode(",",$transaction_data['emi_ids']);
		$status = $transaction_data['emi_type'];
		$plan_name = $transaction_data['plan_name'];
		$data_emi = array();
		if($status == 'plan_emi'){
			foreach($emi_values as $keys=>$values){
				$emi_data = $this->db->select('plan_emi,emi_id,added_date,emi_no,emi_month')->where('emi_id',$values)->get('tbl_emi')->row_array();				
				$data = array(
					'emi_amount' => $emi_data['plan_emi'],
					'emi_id'=> $emi_data['emi_id'],
					'plan_name'=> $plan_name,
					'paid_date'=> $emi_data['added_date'],
					'emi_number'=> $emi_data['emi_no'],
					'emi_month'=> $emi_data['emi_month'],
				);
				$data_emi[] = $data;
			}			
		}
		if($status == 'chit_emi'){
			foreach($emi_values as $keys=>$values){				
				$emi_data = $this->db->select('chit_emi,chit_emi_id,added_date,emi_no,chit_emi_months')->where('chit_emi_id',$values)->get('chit_emi')->row_array();				
				$data = array(
					'emi_amount' => $emi_data['chit_emi'],
					'emi_id'=> $emi_data['chit_emi_id'],
					'plan_name'=> $plan_name,
					'paid_date'=> $emi_data['added_date'],
					'emi_number'=> $emi_data['emi_no'],
					'emi_month'=> $emi_data['chit_emi_months'],
				);
				$data_emi[] = $data;
			}
		}				
		if(!empty($data_emi)){
			$output = array(
				'status'=>'success',
				'message'=>'Transaction history fatch successfull',
				'data'=>$data_emi
			);
		}else{
			$output = array(
				'status'=>'failed',
				'message'=>'No Data Found',
				'data'=>[]
			);
		}
		echo json_encode($output);die;
	}
	
	public function startAuctionAutomatically(){ //15jan2022
	   // $this->load->helper('file');
    //     $data = 'My Text here';
    //     $data .= PHP_EOL;
    //     write_file('/home1/molni2j8/public_html/www.premad.in/chitfund_api/images/product/cron_log.txt', json_encode($data));
        
		$date = date('m/d/Y');
		$time = date('H:i:s');	
		$auction_detail = $this->db->where('status','2')->where('start_date',$date)->get('tbl_auction')->result_array();
		foreach($auction_detail as $keys=>$values){
			$starttime=$values['start_time'];
			$auction_id = $values['auction_id'];
			if($time>$starttime){					
					$data = array(
						'status' => '1'
					);
				$update = $this->db->where('auction_id',$auction_id)->update('tbl_auction',$data);
				$output = array(
					'success'=>'success',
					'message'=>'auction start',
					'auction_id'=>$auction_id
				);
				echo json_encode($output);die;
			}			
			
		}			
	}
	
	public function getsubscriberchit(){
		$data = json_decode($this->data);
		$member_id = $data->member_id;
		$chit_detail = $this->db->where('member_id',$member_id)->get('tbl_chits')->row_array();
		$plan_id = $chit_detail['plan_id'];
		$group_id = $chit_detail['group_id'];
		$member_id = $chit_detail['member_id'];
		$all_data = array();
		$plan_name_detail = $this->db->select('plan_name')->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
		$group_name_detail = $this->db->select('group_name')->where('group_id',$group_id)->get('tbl_groups')->row_array();
		$member_name_detail = $this->db->select('name')->where('member_id',$member_id)->get('tbl_members')->row_array();
		$member_name = $member_name_detail;
		$all_data[] = array_merge($plan_name_detail,$group_name_detail,$member_name,$chit_detail);
		if(!empty($chit_detail)){
			$output = array(
				'status'=>'success',
				'message'=>'chit detail fatch successfull',
				'data'=>$all_data
			);
		}else{
			$output = array(
				'status'=>'failed',
				'message'=>'No Data Found',
				'data'=>''
			);
		}
		echo json_encode($output);die;
	}
	
	public function GetBankAccountsList(){
		$data = $this->db->get('bank_accounts')->result_array();
		if(!empty($data)){
			$output = array(
				'status'=>'success',
				'message'=>'bank detail fatch successfull',
				'data'=>$data
			);
		}else{
			$output = array(
				'status'=>'failed',
				'message'=>'No Data Found',
				'data'=>''
			);
		}
		echo json_encode($output);die;

	}
	
		public function chit_handover(){
		$data = json_decode($this->data);
		$chit_id = isset($data->chit_id) ? $data->chit_id : '';		
		$payment_mode = isset($data->payment_mode) ? $data->payment_mode : '';
		$amount = isset($data->amount) ? $data->amount : '';		
		
		if($payment_mode == 'cheque'){
			$cheque_no = $data->cheque_no;	
			$bank_account_id = $data->bank_account_id;
			$payment_proof =  isset($data->payment_proof) ? $data->payment_proof : '';	     
			$chit_detail_is_hnd = $this->db->select('is_hand_over')->where('chit_id',$chit_id)->get('tbl_chits')->row_array();
			if($chit_detail_is_hnd['is_hand_over']=='Yes'){
				$output = array(
					'status'=>'Failure',
					'message'=>'Chit is already handovered',
					'data'=>''
				);
			}else{
				$bankaccountdetail = $this->db->select('account_number,current_account_balance')->where('bank_account_id',$bank_account_id)->get('bank_accounts')->row_array();	
				$bank_account_number = $bankaccountdetail['account_number'];
				$current_account_balance = $bankaccountdetail['current_account_balance'];
				$chit_data = array(
					'is_payment_by_cheque'=>'Yes',
					'cheque_no'=>$cheque_no,
					'bank_account'=>$bank_account_number,
					'is_hand_over'=>'Yes',
					'payment_mode'=>'Cheque',
					'payment_proof'=>$payment_proof,
					'handover_amount_after_chearing_dues'=>$amount
				);
				$chit_update = $this->db->where('chit_id',$chit_id)->update('tbl_chits',$chit_data);
				$current_bank_amount_less_handover_amount = $current_account_balance-$amount;
				$bank_data = array(
					'current_account_balance'=>$current_bank_amount_less_handover_amount
				);
				$bank_update = $this->db->where('bank_account_id',$bank_account_id)->update('bank_accounts',$bank_data);
				$compney_transaction = array(
					'transaction_type'=>'Chit Handover ',
					'amount'=>$amount,
					'transaction_for'=>'Chit Handover ',
					'comment'=>'Chit Handover ',
					'payment_method'=>'Cheque',
					'bank_account'=>$bank_account_id,
					'cheque_number'=>$cheque_no,
					'image_proof'=>$payment_proof,
				);
				$this->db->insert('company_transaction',$compney_transaction);
				$output = array(
					'status'=>'success',
					'message'=>'Chit handover successfully',
					'data'=>''
				);					
			}		
		}
		if($payment_mode == 'online'){
			$bank_account_id = $data->bank_account_id;
			$payment_proof =  isset($data->payment_proof) ? $data->payment_proof : '';	     
			$chit_detail_is_hnd = $this->db->select('is_hand_over')->where('chit_id',$chit_id)->get('tbl_chits')->row_array();
			if($chit_detail_is_hnd['is_hand_over']=='Yes'){
				$output = array(
					'status'=>'Failure',
					'message'=>'Chit is already handovered',
					'data'=>''
				);
			}else{
				$bankaccountdetail = $this->db->select('account_number,current_account_balance')->where('bank_account_id',$bank_account_id)->get('bank_accounts')->row_array();	
				$bank_account_number = $bankaccountdetail['account_number'];
				$current_account_balance = $bankaccountdetail['current_account_balance'];
				$chit_data = array(
					'is_payment_by_cheque'=>'No',
					'cheque_no'=>'',
					'bank_account'=>$bank_account_number,
					'is_hand_over'=>'Yes',
					'payment_mode'=>'Online',
					'payment_proof'=>$payment_proof,
					'handover_amount_after_chearing_dues'=>$amount
				);
				$chit_update = $this->db->where('chit_id',$chit_id)->update('tbl_chits',$chit_data);
				$current_bank_amount_less_handover_amount = $current_account_balance-$amount;
				$bank_data = array(
					'current_account_balance'=>$current_bank_amount_less_handover_amount
				);
				$bank_update = $this->db->where('bank_account_id',$bank_account_id)->update('bank_accounts',$bank_data);
				$compney_transaction = array(
					'transaction_type'=>'Chit Handover ',
					'amount'=>$amount,
					'transaction_for'=>'Chit Handover ',
					'comment'=>'Chit Handover ',
					'payment_method'=>'Online',
					'bank_account'=>$bank_account_id,
					'cheque_number'=>'No',
					'image_proof'=>$payment_proof,
				);
				$this->db->insert('company_transaction',$compney_transaction);
				$output = array(
					'status'=>'success',
					'message'=>'Chit handover successfully',
					'data'=>''
				);					
			}
		}
		if($payment_mode == 'offline'){
			$payment_proof =  isset($data->payment_proof) ? $data->payment_proof : '';	     
			$chit_detail_is_hnd = $this->db->select('is_hand_over')->where('chit_id',$chit_id)->get('tbl_chits')->row_array();
			if($chit_detail_is_hnd['is_hand_over']=='Yes'){
				$output = array(
					'status'=>'Failure',
					'message'=>'Chit is already handovered',
					'data'=>''
				);
			}else{				
				$chit_data = array(
					'is_payment_by_cheque'=>'No',
					'cheque_no'=>'',
					'bank_account'=>'',
					'is_hand_over'=>'Yes',
					'payment_mode'=>'Offline/Cash',
					'payment_proof'=>$payment_proof,
					'handover_amount_after_chearing_dues'=>$amount
				);		
				$chit_update = $this->db->where('chit_id',$chit_id)->update('tbl_chits',$chit_data);
				$compney_transaction = array(
					'transaction_type'=>'Chit Handover ',
					'amount'=>$amount,
					'transaction_for'=>'Chit Handover ',
					'comment'=>'Chit Handover ',
					'payment_method'=>'Offline/Cash',
					'bank_account'=>'No',
					'cheque_number'=>'No',
					'image_proof'=>$payment_proof,
				);
				$this->db->insert('company_transaction',$compney_transaction);
				$output = array(
					'status'=>'success',
					'message'=>'Chit handover successfully',
					'data'=>''
				);					
			}
		}
		echo json_encode($output);die;
	}
	
	public function SubmitCompanyTransaction(){
		$data = json_decode($this->data);
		$transaction_type = $data->transaction_type;
		$amount = $data->amount;
		$transaction_for = $data->transaction_for;
		$payment_method = $data->payment_method;	
		$type = $data->type;	
		$image_proof = $data->image_proof;
		  
		if($transaction_type == 'subscriber_money'){
			$subscriber = $data->member_id;
		}
		if($transaction_type == 'service_provider'){
			$service_provider = $data->service_provider;
		}

		if($payment_method == 'cheque'){
			$cheque_number = $data->cheque_number;
			$bank_account = $data->bank_account;
			$is_payment_by_cheque = 'Yes';
		}

		if($payment_method == 'online'){
			$bank_account = $data->bank_account;
		}
		if($type == 'receipt'){
			$received_by = $data->received_by;
		}
		if($type == 'payment'){
			$paid_by = $data->paid_by;
		}
		$added_date = date('m/d/Y H:i:m');
		$submit_data = array(
			'transaction_type'=>isset($transaction_type) ? $transaction_type : 'null',
			'subscriber'=>isset($subscriber) ? $subscriber : 'null',
			'service_provider'=>isset($service_provider) ? $service_provider : 'null',
			'amount'=>isset($amount) ? $amount : 'null',			
			'transaction_for'=>isset($transaction_for) ? $transaction_for : 'null',
			'comment'=>isset($comment) ? $comment : 'null',
			'payment_method'=>isset($payment_method) ? $payment_method : 'null',
			'bank_account'=>isset($bank_account) ? $bank_account : 'null',
			'is_payment_by_cheque'=>isset($is_payment_by_cheque) ? $is_payment_by_cheque : 'null',
			'cheque_number'=>isset($cheque_number) ? $cheque_number : 'null',
			'type'=>isset($type) ? $type : 'null',
			'received_by'=>isset($received_by) ? $received_by : 'null',
			'paid_by'=>isset($paid_by) ? $paid_by : 'null',
			'image_proof'=>isset($image_proof) ? $image_proof : 'null',
			'added_date'=>isset($added_date) ? $added_date : 'null',
		);
		$this->db->insert('company_transaction',$submit_data);
		$insert_id = $this->db->insert_id();
		if(!empty($insert_id)){
			$output = array(
				'status'=>'success',
				'message'=>'submit data successfully',
				'data'=>''
			);
		}else{
			$output = array(
				'status'=>'failed',
				'message'=>'No Data Found',
				'data'=>''
			);
		}
		echo json_encode($output);die;

	}
	
public function endauctionnow(){
		$data = json_decode($this->data);
		$auction_id = isset($data->auction_id) ? $data->auction_id : '';
		$submit_data = $this->db->where('auction_id',$auction_id)->where('status','1')->get('tbl_auction')->row_array();
		
			if(!empty($submit_data)){					
					$auction_status = array(
						'status' => '0'
					);
				$update = $this->db->where('auction_id',$auction_id)->update('tbl_auction',$auction_status);
				$auction_detail = $this->db->where('auction_id',$auction_id)->get('tbl_auction')->row_array();
				$plan_id =  $auction_detail['plan_id'];
				$group_id = $auction_detail['group_id'];
				$return_chit_amount = $auction_detail['plan_amount'];
				$bid_id = $auction_detail['winning_bid_id'];
				
				$total_amount_paid = '0';
				$is_on_EMI = 'yes';				
				$bid_detail = $this->db->select('bid_amount')->where('auction_id',$auction_id)->get('tbl_bids')->result_array();
				$array_new = array();
				foreach($bid_detail as $keys=>$values){
					$array_new[] = $values['bid_amount'];
				}
				$min_bid = min($array_new);
				$bid_id = $this->db->select('bid_id')->where('auction_id',$auction_id)->where('bid_amount',$min_bid)->get('tbl_bids')->row_array();
				$min_bid_id = $bid_id['bid_id'];				
				$winning_bid_id = array(
					'winning_bid_id'=> isset($min_bid_id) ? $min_bid_id  : '',
				);
				$winning_id_update = $this->db->where('auction_id',$auction_id)->update('tbl_auction',$winning_bid_id);
				$bid_data = $this->db->where('bid_id',$min_bid_id)->get('tbl_bids')->row_array();
				$chit_amount = $bid_data['bid_amount'];
				$member_id = $bid_data['member_id'];
				$plan_id = $bid_data['plan_id'];
				$plan_details = $this->db->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
				$total_amount_due = $plan_details['plan_amount'];
				$plan_tenure = $plan_details['tenure'];
				$plan_months_completed = $plan_details['months_completed'];
				$remaining_month = $plan_details['remaining_month'];
				$emiamountupdate = array(
					'months_completed' => $plan_months_completed+1,
					'remaining_month' => $remaining_month-1
				);
				$this->db->where('plan_id',$plan_id)->update('tbl_plans',$emiamountupdate);
				$forgo_amount = $total_amount_due - $chit_amount;
				$emi_amount = ($total_amount_due / ($plan_tenure-$plan_months_completed));
				$total_emi = $plan_tenure - $plan_months_completed;//
				$due_emi = $plan_tenure - $plan_months_completed;
				$emi_paid = '0';
				$is_active = '1';
				
				$data = array(
					'plan_id' => isset($plan_id) ? $plan_id : '',//
					'group_id' =>  isset($group_id) ? $group_id : '',//
					'member_id' =>  isset($member_id) ? $member_id : '',//
					'auction_id' =>  isset($auction_id) ? $auction_id : '',//
					'return_chit_amount' =>  isset($return_chit_amount) ? $return_chit_amount : '',//
					'total_amount_paid' => isset($total_amount_paid) ? $total_amount_paid : '',//
					'total_amount_due' => isset($total_amount_due) ? $total_amount_due : '',//
					'chit_amount' => isset($chit_amount) ? $chit_amount : '',//
					'forgo_amount' => isset($forgo_amount) ? $forgo_amount : '',//
					'is_on_EMI' => isset($is_on_EMI) ? $is_on_EMI : '',//
					'emi_amount' => isset($emi_amount) ? $emi_amount : '',//
					'total_emi' => isset($total_emi) ? $total_emi : '',//
					'due_emi' => isset($due_emi) ? $due_emi : '',//
					'emi_paid' => isset($emi_paid) ? $emi_paid : '',//
					'is_active' => isset($is_active) ? $is_active : '',	//	 
				); 			
				 $emi_amount = round($emi_amount, 0);
				 $chit_emi_months = $plan_months_completed+1;
				$insertdata = $this->db->insert('tbl_chits',$data);
				for($i=1; $i<=$total_emi; $i++){
					$data2 = array(
						'plan_id' => isset($plan_id) ? $plan_id : '',//
						'member_id' => isset($member_id) ? $member_id : '',//
						'group_id' => isset($group_id) ? $group_id : '',//
						'emi_no' => $i,//
						'chit_emi' => isset($emi_amount) ? $emi_amount : '',//
						'total_emi' => isset($total_emi) ? $total_emi : '',//
						'emi_status' => 'due',//
						'chit_amount' => isset($chit_amount) ? $chit_amount : '',
						'return_chit_amount' => isset($return_chit_amount) ? $return_chit_amount : '',//
						'return_factor' => '0',//
						'chit_emi_months' => isset($chit_emi_months) ? $chit_emi_months : '',//
						'is_partial_payment' => 'No'
					);
				// 		$insert_chit_emi = $this->db->insert('chit_emi',$data2);
						$chit_emi_months++;
				}
				$win_bid_acc = array(
					'is_bid_accepted'=>'yes'
				);
				$this->db->where('bid_id',$min_bid_id)->update('tbl_bids',$win_bid_acc);				
				$member_name_detail = $this->db->select('name')->where('member_id',$member_id)->get('tbl_members')->row_array();
						$member_name = $member_name_detail['name'];
						$foreman_fees_detail = $this->db->select('foreman_fees,total_months')->where('plan_id',$plan_id)->get('tbl_plans')->row_array();
						$foreman_fees = $foreman_fees_detail['foreman_fees'];
						$total_months = $foreman_fees_detail['total_months'];
						$group_details_member = $this->db->select('total_members')->where('group_id',$group_id)->get('tbl_groups')->row_array(); 
						$group_member = $group_details_member['total_members'];
						$forman_amount = $total_amount_due*$foreman_fees/100;
						$divident_amount = ($total_amount_due -($chit_amount + $forman_amount)) / $group_member;	
						$divident_data = array(
							'member_name'=>isset($member_name) ? $member_name : '',
							'member_id'=>isset($member_id) ? $member_id : '',
							'plan_id'=>isset($plan_id) ? $plan_id : '',
							'group_id'=>isset($group_id) ? $group_id : '',
							'auction_id'=>$auction_id,
							'divident_amount'=>$divident_amount,
							'month'=>isset($auction_no) ? $auction_no : '',
							'total_months'=>isset($total_months) ? $total_months : '',		
						);
						$dividint_months_sub = $plan_months_completed+1;
							$this->db->insert('tbl_divident',$divident_data);
							$emidivident = array(
								'divident' => $divident_amount
							);
							$this->db->where('emi_no',$dividint_months_sub)->where('member_id',$member_id)->where('plan_id',$plan_id)->update('tbl_emi',$emidivident);
							
				$output = array(
					'status'=>'success',
					'message'=>'auction close',	
					'winning bid id'=>$min_bid_id,			
					'auction_id'=>$auction_id
				);
			}
			else{
			   	$output = array(
					'status'=>'Failure',
					'message'=>'auction is already close',	
					'winning bid id'=>0,			
					'auction_id'=>0
				);
			}
		echo json_encode($output);die;
	}
	
	
	public function cancelSubscription(){
	  $data =  json_decode($this->data);
      $slot_number = isset($data->slot_number) ? $data->slot_number : '';
      $order_id = isset($data->order_id) ? $data->order_id : '';
      $reason = isset($data->reason) ? $data->reason : '';
	  if($slot_number != '' && $order_id !=''){
        $this->db->where('slot_number',$slot_number)->where('order_id',$order_id)->update('tbl_orders',array('slot_status' => 'cancelled','cancel_reason' => $reason ));
        $getdata1 = $this->db->where('order_id',$order_id)->get('tbl_orders')->row_array();
        $member_id = isset($getdata1['member_id']) ? $getdata1['member_id'] : '';
        $plan_id = isset($getdata1['plan_id']) ? $getdata1['plan_id'] : '';
        $group_id = isset($getdata1['group_id']) ? $getdata1['group_id'] : '';

    	$data1 = array(
			'emi_status'  => "cancelled",
			'added_date' => date('Y-m-d h:i:s')
		);
		$this->db->where('member_id',$member_id)->where('plan_id',$plan_id)->where('group_id',$group_id)->where('emi_status','due')->update('tbl_emi',$data1);
        $getdata = $this->db->where('slot_number',$slot_number)->where('order_id',$order_id)->get('tbl_orders')->row_array();
        $planDetails = $this->db->where('plan_id',$getdata['plan_id'])->get('tbl_plans')->row_array();
        $data = array(
    	    'member_id' => '',
    	    'plan_id'   => isset($getdata['plan_id']) ? $getdata['plan_id'] : '',
    	    'group_id'  => isset($getdata['group_id']) ? $getdata['group_id'] : '',
    	    'member_name' => '',
    	    'plan_amount' => isset($getdata['plan_amount']) ? $getdata['plan_amount'] : '',
    	    'start_month' => isset($getdata['start_month']) ? $getdata['start_month'] : '',
    	    'emi' => isset($getdata['emi']) ? $getdata['emi'] : '',
    	    'tenure' => isset($getdata['tenure']) ? $getdata['tenure'] : '',
    	    'months_completed' => isset($planDetails['months_completed']) ? $planDetails['months_completed'] : '',
    	    'agent_commission' => isset($getdata['agent_commission'])  ? $getdata['agent_commission'] : '',
    	    'end_month' => isset($getdata['end_month']) ? $getdata['end_month'] : '',
    	    'total_months' => isset($getdata['total_months']) ? $getdata['total_months'] : '',
    	    'groups_count'  => isset($planDetails['groups_counts']) ? $planDetails['groups_counts'] : '',
    	    'admission_fees'    => isset($getdata['admission_fees']) ? $getdata['admission_fees'] : '',
    	    'agent_id'  => '0',
    	    'is_added_by_agent' => '0',
    	    'transaction_id' => '',
    	    'payment_mode' => 'offline',
    	    'slot_number' => isset($getdata['slot_number']) ? $getdata['slot_number'] : '',
    	    'added_date' => date('Y-m-d h:i:s')
        );
        $this->db->insert('tbl_orders',$data);
        $insert_id = $this->db->insert_id();
        if($insert_id != ''){
            $output = array(
               'status' => Success,
               'message' => 'Cancel Subscription',
               'data' => []
            );
        }else{
           $output = array(
               'status' => Failure,
               'message' => 'Something Wrong',
               'data' => []
            ); 
        }
        
	  }else{
	    $output = array(
	      'status' => Failure,
	      'message' => "Data not found",
	      'data' => []
	    ); 
	  }
	  echo json_encode($output); die;
	}
	
	public function resignSlotSubcription(){
	  $data =  json_decode($this->data);
      $slot_number = isset($data->slot_number) ? $data->slot_number : '';
      $member_id = isset($data->member_id) ? $data->member_id : '';
      $order_id = isset($data->order_id) ? $data->order_id : '';
     if($slot_number != '' && $member_id != ''){
      $member_details = $this->db->where('member_id',$member_id)->get('tbl_members')->row_array();
      $data = array(
        'member_id' => isset($member_id) ? $member_id : '',
        'member_name' => isset($member_details['name']) ? $member_details['name'] : '',
        'slot_status' => 'assigned'
      );
      $this->db->where('slot_number',$slot_number)->where('slot_status','vacant')->where('order_id',$order_id)->update('tbl_orders',$data);
      $getorder =  $this->db->where('order_id',$order_id)->get('tbl_orders')->row_array();
      $start_month = isset($getorder['start_month']) ? $getorder['start_month'] : '';
      $emi = isset($getorder['emi']) ? $getorder['emi'] : '';
	  $months = explode(" ",$getorder['tenure']);
	  $getmonths = isset($months[0]) ? $months[0] : ''; 
	 
	  $date2 = date('m', strtotime($start_month));
	  $date2 = 0;
	  $emi = round($emi, 0);
	  for($i=1; $i<=$getmonths; $i++){
		 // one column add in emi table plan name (pending)
		$date3 = date('M', strtotime($start_month. ' + '.$date2.'month'));
		$date2  = $date2 + 1; 
		$data1 = array(
		'member_id' => isset($getorder['member_id']) ? $getorder['member_id'] : '',
		'plan_id'   => isset($getorder['plan_id']) ? $getorder['plan_id'] : '',
		'group_id'  => isset($getorder['group_id']) ? $getorder['group_id'] : '',
		'emi_month' => $date3,
		'plan_emi' => isset($emi) ? $emi : '',
		'emi_no' => $i,
		'total_emi' => isset($getorder['total_months']) ? $getorder['total_months'] : '',
		'emi_status'  => "due",
		'is_partial_payment' => "No",
		'is_chit_taken' => "no",
		'chit_status' => 'close',
		'added_date' => date('Y-m-d h:i:s')
	   );
	   $this->db->insert('tbl_emi',$data1);
	   $insert_id1 = $this->db->insert_id();
	   if(!empty($insert_id1)){
			$output = array(
				'status' => Success,
				'message' => 'Created Emi Successfully',
				'data' => [],
			);	 
	   }else{
		  $output = array(
				'status' => Failure,
				'message' => "Invalid Data.",
				'data' => []
			); 
		}
	 }
    $output = array(
       'status' => Success,
       'message' => 'Insert Order table  Subscription',
       'data' => []
    );
      
     }else{
        $output = array(
	      'status' => Failure,
	      'message' => "Slot number and Member Id are blanked",
	      'data' => []
	    ); 
     }
     echo json_encode($output); die;
	}
	
   public function getControlSheet(){
    $getOrder = $this->db->where('member_id !=',0)->group_by('member_id')->get('tbl_orders')->result_array();
    if(!empty($getOrder)){
     $emi_arr = array();
     $total_arr = array();
     foreach($getOrder as $key => $value){
       $member_id = isset($value['member_id']) ? $value['member_id'] : '';
       $member_name = isset($value['member_name']) ? $value['member_name'] : '';
       $emi_arr[] = $this->db->select('plan_emi,emi_status')->where('member_id',$member_id)->where('emi_status !=','cancelled')->get('tbl_emi')->result_array();
       foreach($emi_arr as $key1 => $value1){
          $sum_due = 0;  $sum_paid = 0;
         foreach($value1 as $key2 => $value2){
           $emi_status = isset($value2['emi_status']) ? $value2['emi_status'] : '';
           $sum_due = $sum_due+$value2['plan_emi'];
          if($emi_status == 'paid'){
             $sum_paid = $sum_paid+$value2['plan_emi'];  
          }
         }
       }
       $total_arr[$key]['Member_id'] = isset($member_id) ? $member_id : '';
       $total_arr[$key]['Member_name'] = isset($member_name) ? $member_name : '';
       $total_arr[$key]['Total_emi_due'] = isset($sum_due) ? $sum_due : '';
       $total_arr[$key]['Total_emi_paid'] = isset($sum_paid) ? $sum_paid : '';
       $total_arr[$key]['Balance'] = $sum_paid - $sum_due;
     }
      $output = array(
       'status' => Success,
       'message' => 'Control Sheet Fetched Successfully',
       'data' => $total_arr
      );
    }else{
        $output = array(
	      'status' => Failure,
	      'message' => "Data Not Found",
	      'data' => []
	    );  
    }
    echo json_encode($output); die;
   }
   
   public function addCollateral(){
    $data =  json_decode($this->data);
    $data1 = array(
       'name' => isset($data->collateral_name) ? $data->collateral_name : '',
       'description' => isset($data->description) ? $data->description : '',
       'parent_id' => isset($data->parent_id) ? $data->parent_id : '',
       'added_date' => date('y-m-d h:i:s')
    );
    $this->db->insert('tbl_collateral_master',$data1);
    $insert_id1 = $this->db->insert_id();
   
    if($insert_id1 != ''){
      $output = array(
       'status' => Success,
       'message' => 'Add Collateral Successfully',
       'data' => []
      );
    }else{
      $output = array(
	      'status' => Failure,
	      'message' => "Add Collateral Unsuccessfully",
	      'data' => []
	  );    
    }
    echo json_encode($output); die;
   }
   
    public function listCollateral(){
      $getCollateral =  $this->db->get('tbl_collateral_master')->result_array();
      if(!empty($getCollateral)){
          $output = array(
           'status' => Success,
           'message' => 'GET Collateral Fetched Successfully',
           'data' => $getCollateral
          );
      }else{
         $output = array(
	      'status' => Failure,
	      'message' => "GET Collateral Unsuccessfully",
	      'data' => []
	     );     
      }
      echo json_encode($output); die;
    }
    
    public function addSubscriberCollateral(){
      $data =  json_decode($this->data);
      $collateral_id = isset($data->collateral_id) ? $data->collateral_id : '';
      $sub_collateral_id = isset($data->sub_collateral_id) ? $data->sub_collateral_id : '';
      $selectSubscription = isset($data->selectSubscription) ? $data->selectSubscription : '';
      $member_id = isset($data->member_id) ? $data->member_id : '';
      $member_name = $this->db->select('name')->where('member_id',$member_id)->get('tbl_members')->row_array();
      $collateral_name = $this->db->select('name')->where('collateral_id',$collateral_id)->get('tbl_collateral_master')->row_array();
      $sub_collateral_name = $this->db->select('name')->where('parent_id',$collateral_id)->get('tbl_collateral_master')->row_array();
      $data = array(
        'collateral_id' => isset($collateral_id) ? $collateral_id : '',
        'collateral_sub_type_id' => isset($sub_collateral_id) ? $sub_collateral_id : '',
        'member_id' => isset($member_id) ? $member_id : '',
        'member_name' => isset($member_name['name']) ? $member_name['name'] : '',
        'collateral_name' => isset($collateral_name['name']) ? $collateral_name['name'] : '',
        'collateral_sub_name' => isset($sub_collateral_name['name']) ? $sub_collateral_name['name'] : '',
        'subscription_locked' => isset($selectSubscription) ? $selectSubscription : ''
      );
      $this->db->insert('tbl_subscriber_collateral',$data);
      $insert_id = $this->db->insert_id();
      if($insert_id != ''){
          $output = array(
           'status' => Success,
           'message' => 'Add Subscriber Collateral Successfully',
           'data' => []
          );
      }else{
         $output = array(
	      'status' => Failure,
	      'message' => "Add Subscriber Collateral Unsuccessfully",
	      'data' => []
	     );     
      }
      echo json_encode($output); die;
    }
    
    public function reports(){
     $data =  json_decode($this->data); 
     $member_id = isset($data->member_id) ? $data->member_id : '';
     if($member_id != ''){
      $sql = "SELECT tbl_orders.order_id, tbl_plans.* FROM tbl_orders INNER JOIN tbl_plans ON tbl_orders.plan_id=tbl_plans.plan_id WHERE tbl_orders.member_id=$member_id";
      $getOrderData = $this->db->query($sql)->result_array();

      $output = array(
       'status' => Success,
       'message' => 'Get Reports Fetched Successfully',
       'data' => $getOrderData
      );
     }else{
        $output = array(
	      'status' => Failure,
	      'message' => "Invalid Member Id",
	      'data' => []
	     );  
     }
     echo json_encode($output); die;
    }
}